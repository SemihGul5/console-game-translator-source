package com.revenuecat.purchases

import android.content.Context
import com.revenuecat.purchases.common.safeResume
import com.revenuecat.purchases.common.safeResumeWithException
import com.revenuecat.purchases.models.BillingFeature
import com.revenuecat.purchases.models.StoreProduct
import com.revenuecat.purchases.models.StoreTransaction
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Fetch the configured offerings for this users. Offerings allows you to configure your in-app
 * products via RevenueCat and greatly simplifies management. See
 * [the guide](https://docs.revenuecat.com/offerings) for more info.
 *
 * Offerings will be fetched and cached on instantiation so that, by the time they are needed,
 * your prices are loaded for your purchase flow. Time is money.
 *
 * Coroutine friendly version of [Purchases.getOfferings].
 *
 * @throws [PurchasesException] with a [PurchasesError] if there's an error retrieving the offerings.
 * @return The [Offerings] available to this user.
 */
@JvmSynthetic
@Throws(PurchasesException::class)
public suspend fun Purchases.awaitOfferings(): Offerings {
    return suspendCancellableCoroutine { continuation ->
        getOfferingsWith(
            onSuccess = { continuation.safeResume(it) },
            onError = { continuation.safeResumeWithException(PurchasesException(it)) },
        )
    }
}

/**
 * Fetch the configured offerings for this users. Offerings allows you to configure your in-app
 * products via RevenueCat and greatly simplifies management. See
 * [the guide](https://docs.revenuecat.com/offerings) for more info.
 *
 * Offerings will be fetched and cached on instantiation so that, by the time they are needed,
 * your prices are loaded for your purchase flow. Time is money.
 *
 * Coroutine friendly version of [Purchases.getOfferings].
 *
 * @return A [Result] containing [Offerings] available to the user if the execution succeeds,
 * or a [Result] containing [PurchasesException] if it fails.
 */
@JvmSynthetic
public suspend fun Purchases.awaitOfferingsResult(): Result<Offerings> =
    suspendCancellableCoroutine { continuation ->
        getOfferingsWith(
            onSuccess = { continuation.safeResume(Result.success(it)) },
            onError = { continuation.safeResume(Result.failure(PurchasesException(it))) },
        )
    }

/**
 * Initiate a purchase with the given [PurchaseParams].
 * Initialized with an [Activity] either a [Package], [StoreProduct], or [SubscriptionOption].
 *
 * If a [Package] or [StoreProduct] is used to build the [PurchaseParams], the [StoreProduct.defaultOption] will
 * be purchased.
 * [StoreProduct.defaultOption] is selected via the following logic:
 *   - Filters out offers with "rc-ignore-offer" and "rc-customer-center" tag
 *   - Uses [SubscriptionOption] with the longest free trial or cheapest first phase
 *   - Falls back to use base plan
 *
 * @params [purchaseParams] The parameters configuring the purchase. See [PurchaseParams.Builder] for options.
 * @throws [PurchasesTransactionException] with a [PurchasesError] if there's an error when purchasing
 * and a userCancelled boolean that indicates if the user cancelled the purchase flow.
 * @return The [StoreTransaction] for this purchase and the updated [CustomerInfo] for this user.
 */
@JvmSynthetic
@Throws(PurchasesTransactionException::class)
public suspend fun Purchases.awaitPurchase(purchaseParams: PurchaseParams): PurchaseResult {
    return suspendCancellableCoroutine { continuation ->
        purchase(
            purchaseParams = purchaseParams,
            callback = purchaseCompletedCallback(
                onSuccess = { storeTransaction, customerInfo ->
                    continuation.safeResume(PurchaseResult(storeTransaction, customerInfo))
                },
                onError = { purchasesError, userCancelled ->
                    continuation.safeResumeWithException(
                        PurchasesTransactionException(purchasesError, userCancelled),
                    )
                },
            ),
        )
    }
}

/**
 * Initiate a purchase with the given [PurchaseParams].
 * Initialized with an [Activity] either a [Package], [StoreProduct], or [SubscriptionOption].
 *
 * If a [Package] or [StoreProduct] is used to build the [PurchaseParams], the [StoreProduct.defaultOption] will
 * be purchased.
 * [StoreProduct.defaultOption] is selected via the following logic:
 *   - Filters out offers with "rc-ignore-offer" and "rc-customer-center" tag
 *   - Uses [SubscriptionOption] with the longest free trial or cheapest first phase
 *   - Falls back to use base plan
 *
 * @params [purchaseParams] The parameters configuring the purchase. See [PurchaseParams.Builder] for options.
 * @return The [Result] of [PurchaseResult] contains [StoreTransaction] for this purchase and the updated,
 * [CustomerInfo] for this user if the execution succeeds, or a [Result] containing
 * [PurchasesException] if it fails.
 */
@JvmSynthetic
public suspend fun Purchases.awaitPurchaseResult(purchaseParams: PurchaseParams): Result<PurchaseResult> {
    return suspendCancellableCoroutine { continuation ->
        purchase(
            purchaseParams = purchaseParams,
            callback = purchaseCompletedCallback(
                onSuccess = { storeTransaction, customerInfo ->
                    continuation.safeResume(Result.success(PurchaseResult(storeTransaction, customerInfo)))
                },
                onError = { purchasesError, userCancelled ->
                    continuation.safeResume(
                        Result.failure(PurchasesTransactionException(purchasesError, userCancelled)),
                    )
                },
            ),
        )
    }
}

/**
 * Gets the StoreProduct(s) for the given list of product ids of type [type], or for all types if no type is specified.
 *
 * Coroutine friendly version of [Purchases.getProducts].
 *
 * @param [productIds] List of productIds
 * @param [type] A product type to filter by
 *
 * @throws [PurchasesException] with a [PurchasesError] if there's an error retrieving the products.
 * @return A list of [StoreProduct] with the products that have been able to be fetched from the store successfully.
 * Not found products will be ignored.
 */
@JvmSynthetic
@Throws(PurchasesTransactionException::class)
public suspend fun Purchases.awaitGetProducts(
    productIds: List<String>,
    type: ProductType? = null,
): List<StoreProduct> {
    return suspendCancellableCoroutine { continuation ->
        getProductsWith(
            productIds,
            type,
            onGetStoreProducts = { continuation.safeResume(it) },
            onError = {
                continuation.safeResumeWithException(PurchasesException(it))
            },
        )
    }
}

/**
 * Gets the StoreProduct(s) for the given list of product ids of type [type], or for all types if no type is specified.
 *
 * Coroutine friendly version of [Purchases.getProducts].
 *
 * @param [productIds] List of productIds
 * @param [type] A product type to filter by
 *
 * @return A [Result] of list of [StoreProduct] with the products that have been able to be fetched from the
 * store successfully, or a [Result] containing  [PurchasesException] if it fails.
 * Not found products will be ignored.
 */
@JvmSynthetic
public suspend fun Purchases.awaitGetProductsResult(
    productIds: List<String>,
    type: ProductType? = null,
): Result<List<StoreProduct>> {
    return suspendCancellableCoroutine { continuation ->
        getProductsWith(
            productIds,
            type,
            onGetStoreProducts = { storeProducts ->
                continuation.safeResume(Result.success(storeProducts))
            },
            onError = {
                continuation.safeResume(Result.failure(PurchasesException(it)))
            },
        )
    }
}

/**
 * Restores purchases made with the current Play Store account for the current user.
 * This method will post all purchases associated with the current Play Store account to
 * RevenueCat and become associated with the current `appUserID`. If the receipt token is being
 * used by an existing user, the current `appUserID` will be aliased together with the
 * `appUserID` of the existing user. Going forward, either `appUserID` will be able to reference
 * the same user.
 *
 * You shouldn't use this method if you have your own account system. In that case
 * "restoration" is provided by your app passing the same `appUserId` used to purchase originally.
 *
 * Coroutine friendly version of [Purchases.restorePurchases].
 *
 * @throws [PurchasesException] with a [PurchasesError] if there's an error login out the user.
 * @return The [CustomerInfo] with the restored purchases.
 */
@JvmSynthetic
@Throws(PurchasesTransactionException::class)
public suspend fun Purchases.awaitRestore(): CustomerInfo {
    return suspendCancellableCoroutine { continuation ->
        restorePurchasesWith(
            onSuccess = { continuation.safeResume(it) },
            onError = { continuation.safeResumeWithException(PurchasesException(it)) },
        )
    }
}

/**
 * Restores purchases made with the current Play Store account for the current user.
 * This method will post all purchases associated with the current Play Store account to
 * RevenueCat and become associated with the current `appUserID`. If the receipt token is being
 * used by an existing user, the current `appUserID` will be aliased together with the
 * `appUserID` of the existing user. Going forward, either `appUserID` will be able to reference
 * the same user.
 *
 * You shouldn't use this method if you have your own account system. In that case
 * "restoration" is provided by your app passing the same `appUserId` used to purchase originally.
 *
 * Coroutine friendly version of [Purchases.restorePurchases].
 *
 * @return The [Result] of [CustomerInfo] with the restored purchases if the execution succeeds,
 * or a [Result] containing [PurchasesException] if it fails.
 */
@JvmSynthetic
public suspend fun Purchases.awaitRestoreResult(): Result<CustomerInfo> {
    return suspendCancellableCoroutine { continuation ->
        restorePurchasesWith(
            onSuccess = { customerInfo ->
                continuation.safeResume(Result.success(customerInfo))
            },
            onError = {
                continuation.safeResume(Result.failure(PurchasesException(it)))
            },
        )
    }
}

/**
 * This method will try to obtain the Store (Google/Amazon) country code in ISO-3166-1 alpha2.
 * If there is any error, it will return null and log said error.
 * Coroutine friendly version of [Purchases.getStorefrontCountryCode].
 *
 * @throws [PurchasesException] with a [PurchasesError] if there's an error retrieving the country code.
 * @return The Store country code in ISO-3166-1 alpha2.
 */
public suspend fun Purchases.awaitStorefrontCountryCode(): String {
    return suspendCancellableCoroutine { continuation ->
        getStorefrontCountryCodeWith(
            onSuccess = { continuation.safeResume(it) },
            onError = { continuation.safeResumeWithException(PurchasesException(it)) },
        )
    }
}

/**
 * Note: This method only works for the Google Play Store. There is no Amazon equivalent at this time.
 * Calling from an Amazon-configured app will return true.
 *
 * Check if billing is supported for the current Play user (meaning IN-APP purchases are supported)
 * and optionally, whether all features in the list of specified feature types are supported. This method is
 * asynchronous since it requires a connected BillingClient.
 * @param context A context object that will be used to connect to the billing client
 * @param features A list of feature types to check for support. Feature types must be one of [BillingFeature]
 *                 By default, is an empty list and no specific feature support will be checked.
 * @return the result of the check
 */
@JvmSynthetic
public suspend fun Purchases.Companion.awaitCanMakePayments(
    context: Context,
    features: List<BillingFeature> = listOf(),
): Boolean {
    return suspendCancellableCoroutine { continuation ->
        canMakePayments(
            context = context,
            features = features,
            callback = { continuation.safeResume(it) },
        )
    }
}
