@file:OptIn(InternalRevenueCatAPI::class)
@file:Suppress("LongParameterList")

package com.revenuecat.purchases.ads.events

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.VerifiedReward
import com.revenuecat.purchases.ads.events.types.AdFormat
import com.revenuecat.purchases.ads.events.types.AdMediatorName
import com.revenuecat.purchases.ads.events.types.AdRevenuePrecision
import com.revenuecat.purchases.ads.events.types.AdRewardFailureReason
import com.revenuecat.purchases.common.events.BackendEvent
import com.revenuecat.purchases.common.events.FeatureEvent
import java.util.UUID

internal enum class AdEventType(val value: String) {
    DISPLAYED("rc_ads_ad_displayed"),
    OPENED("rc_ads_ad_opened"),
    REVENUE("rc_ads_ad_revenue"),
    LOADED("rc_ads_ad_loaded"),
    FAILED_TO_LOAD("rc_ads_ad_failed_to_load"),
    REWARD_EARNED_UNVERIFIED("rc_ads_ad_reward_sdk_earned"),
    REWARD_VERIFIED("rc_ads_ad_reward_sdk_verified"),
    REWARD_GRANTED("rc_ads_ad_reward_sdk_granted"),
    REWARD_FAILED_TO_VERIFY("rc_ads_ad_reward_sdk_failed_to_verify"),
    REWARDED_AD_PROMPT_SHOWN("rc_ads_rewarded_ad_prompt_shown"),
    REWARDED_AD_PROMPT_ACCEPTED("rc_ads_rewarded_ad_prompt_accepted"),
}

internal sealed interface AdEvent : FeatureEvent {
    val id: String
    val eventVersion: Int
    val type: AdEventType
    val timestamp: Long
    val networkName: String?
    val mediatorName: AdMediatorName
    val adFormat: AdFormat
    val placement: String?
    val adUnitId: String
    val impressionId: String?
    val captureMethod: AdCaptureMethod

    class Displayed(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.DISPLAYED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent

    class Open(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.OPENED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent

    class Revenue(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REVENUE,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
        val revenueMicros: Long,
        val currency: String,
        val precision: AdRevenuePrecision,
    ) : AdEvent

    class Loaded(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.LOADED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent

    class FailedToLoad(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.FAILED_TO_LOAD,
        override val timestamp: Long = System.currentTimeMillis(),
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String? = null,
        override val captureMethod: AdCaptureMethod,
        val mediatorErrorCode: Int?,
    ) : AdEvent {
        override val networkName: String? = null
    }

    class RewardEarnedUnverified(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARD_EARNED_UNVERIFIED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
        val rewardVerificationEnabled: Boolean,
    ) : AdEvent

    class RewardVerified(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARD_VERIFIED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent

    class RewardGranted(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARD_GRANTED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
        val reward: VerifiedReward,
    ) : AdEvent

    class RewardFailedToVerify(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARD_FAILED_TO_VERIFY,
        override val timestamp: Long = System.currentTimeMillis(),
        override val networkName: String?,
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val impressionId: String,
        override val captureMethod: AdCaptureMethod,
        val failureReason: AdRewardFailureReason,
    ) : AdEvent

    class RewardedAdPromptShown(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARDED_AD_PROMPT_SHOWN,
        override val timestamp: Long = System.currentTimeMillis(),
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent {
        override val networkName: String? = null
        override val impressionId: String? = null
    }

    class RewardedAdPromptAccepted(
        override val id: String = UUID.randomUUID().toString(),
        override val eventVersion: Int = BackendEvent.AD_EVENT_SCHEMA_VERSION,
        override val type: AdEventType = AdEventType.REWARDED_AD_PROMPT_ACCEPTED,
        override val timestamp: Long = System.currentTimeMillis(),
        override val mediatorName: AdMediatorName,
        override val adFormat: AdFormat,
        override val placement: String?,
        override val adUnitId: String,
        override val captureMethod: AdCaptureMethod,
    ) : AdEvent {
        override val networkName: String? = null
        override val impressionId: String? = null
    }
}
