package com.revenuecat.purchases.ads.events.types

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.VerifiedReward
import dev.drewhamilton.poko.Poko

/**
 * Data for tracking a single reward grant. One event is tracked per grant when a
 * reward-verification poll returns more than one reward.
 *
 * @property networkName The name of the ad network, or null if unknown.
 * @property mediatorName The name of the ad mediator. See [AdMediatorName] for common values.
 * @property adFormat The format of the ad. See [AdFormat] for common values.
 * @property placement The placement of the ad, if available.
 * @property adUnitId The ad unit ID.
 * @property impressionId The impression ID.
 * @property reward The reward that was granted.
 */
@InternalRevenueCatAPI
@Poko
public class AdRewardGrantedData(
    public val networkName: String?,
    public val mediatorName: AdMediatorName,
    public val adFormat: AdFormat,
    public val placement: String?,
    public val adUnitId: String,
    public val impressionId: String,
    public val reward: VerifiedReward,
)
