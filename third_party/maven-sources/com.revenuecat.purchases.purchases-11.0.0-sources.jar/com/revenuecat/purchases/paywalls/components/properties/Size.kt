package com.revenuecat.purchases.paywalls.components.properties

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.utils.serializers.SealedDeserializerWithDefault
import dev.drewhamilton.poko.Poko
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@InternalRevenueCatAPI
@Poko
@Immutable
@Serializable
public class Size(
    @get:JvmSynthetic public val width: SizeConstraint,
    @get:JvmSynthetic public val height: SizeConstraint,
)

@InternalRevenueCatAPI
@Stable
@Serializable(with = SizeConstraintDeserializer::class)
public sealed interface SizeConstraint {
    // SerialNames are handled by the SizeConstraintDeserializer.

    /**
     * Fits the content size.
     *
     * @param default Optional default size (in dp) to show during loading and initial content size calculations.
     */
    @Poko
    @Immutable
    @Serializable
    public class Fit(
        @get:JvmSynthetic @SerialName("default") public val default: UInt? = null,
    ) : SizeConstraint

    /**
     * Fills the available space, like a flex item with `flex-grow: 1`.
     *
     * @param min Optional minimum size in dp. Reserved before remaining space is shared with Fill siblings.
     * @param max Optional maximum size in dp. Space beyond it is released to Fill siblings.
     */
    @Poko
    @Immutable
    @Serializable
    public class Fill(
        @get:JvmSynthetic public val min: UInt? = null,
        @get:JvmSynthetic public val max: UInt? = null,
    ) : SizeConstraint

    @Poko
    @Immutable
    @Serializable
    public class Fixed(
        @get:JvmSynthetic public val value: UInt,
    ) : SizeConstraint
}

@OptIn(InternalRevenueCatAPI::class)
internal object SizeConstraintDeserializer : SealedDeserializerWithDefault<SizeConstraint>(
    serialName = "SizeConstraint",
    serializerByType = mapOf(
        "fit" to { SizeConstraint.Fit.serializer() },
        "fill" to { SizeConstraint.Fill.serializer() },
        "fixed" to { SizeConstraint.Fixed.serializer() },
    ),
    defaultValue = { SizeConstraint.Fit() },
)
