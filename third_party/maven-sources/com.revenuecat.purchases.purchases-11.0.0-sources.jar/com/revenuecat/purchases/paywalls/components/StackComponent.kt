package com.revenuecat.purchases.paywalls.components

import androidx.compose.runtime.Immutable
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.paywalls.components.common.Background
import com.revenuecat.purchases.paywalls.components.common.ComponentOverride
import com.revenuecat.purchases.paywalls.components.properties.Badge
import com.revenuecat.purchases.paywalls.components.properties.Border
import com.revenuecat.purchases.paywalls.components.properties.ColorScheme
import com.revenuecat.purchases.paywalls.components.properties.Dimension
import com.revenuecat.purchases.paywalls.components.properties.Dimension.Vertical
import com.revenuecat.purchases.paywalls.components.properties.FlexDistribution.START
import com.revenuecat.purchases.paywalls.components.properties.HorizontalAlignment.CENTER
import com.revenuecat.purchases.paywalls.components.properties.Padding
import com.revenuecat.purchases.paywalls.components.properties.Padding.Companion.zero
import com.revenuecat.purchases.paywalls.components.properties.Shadow
import com.revenuecat.purchases.paywalls.components.properties.Shape
import com.revenuecat.purchases.paywalls.components.properties.Size
import com.revenuecat.purchases.paywalls.components.properties.SizeConstraint
import com.revenuecat.purchases.utils.serializers.EnumDeserializerWithDefault
import dev.drewhamilton.poko.Poko
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.nullable
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder

@Suppress("LongParameterList")
@InternalRevenueCatAPI
@Poko
@Serializable
@SerialName("stack")
@Immutable
public class StackComponent(
    @get:JvmSynthetic
    public val components: List<PaywallComponent>,
    @get:JvmSynthetic
    public val visible: Boolean? = null,
    @get:JvmSynthetic
    public val dimension: Dimension = Vertical(CENTER, START),
    @get:JvmSynthetic
    public val size: Size = Size(width = SizeConstraint.Fill(), height = SizeConstraint.Fit()),
    @get:JvmSynthetic
    public val spacing: Float? = null,
    @get:JvmSynthetic
    @SerialName("background_color")
    public val backgroundColor: ColorScheme? = null,
    @get:JvmSynthetic
    public val background: Background? = null,
    @get:JvmSynthetic
    public val padding: Padding = zero,
    @get:JvmSynthetic
    public val margin: Padding = zero,
    @get:JvmSynthetic
    public val shape: Shape? = null,
    @get:JvmSynthetic
    public val border: Border? = null,
    @get:JvmSynthetic
    public val shadow: Shadow? = null,
    @get:JvmSynthetic
    public val badge: Badge? = null,
    @get:JvmSynthetic
    @Serializable(with = NullableStackOverflowDeserializer::class)
    public val overflow: Overflow? = null,
    @get:JvmSynthetic
    public val overrides: List<ComponentOverride<PartialStackComponent>> = emptyList(),
    @get:JvmSynthetic
    public val name: String? = null,
) : PaywallComponent {

    @Serializable(with = StackOverflowDeserializer::class)
    public enum class Overflow {
        // SerialNames are handled by the StackOverflowDeserializer

        NONE,
        SCROLL,
    }
}

@Suppress("LongParameterList")
@InternalRevenueCatAPI
@Poko
@Serializable
@Immutable
public class PartialStackComponent(
    @get:JvmSynthetic
    public val visible: Boolean? = true,
    @get:JvmSynthetic
    public val dimension: Dimension? = null,
    @get:JvmSynthetic
    public val size: Size? = null,
    @get:JvmSynthetic
    public val spacing: Float? = null,
    @get:JvmSynthetic
    @SerialName("background_color")
    public val backgroundColor: ColorScheme? = null,
    @get:JvmSynthetic
    public val background: Background? = null,
    @get:JvmSynthetic
    public val padding: Padding? = null,
    @get:JvmSynthetic
    public val margin: Padding? = null,
    @get:JvmSynthetic
    public val shape: Shape? = null,
    @get:JvmSynthetic
    public val border: Border? = null,
    @get:JvmSynthetic
    public val shadow: Shadow? = null,
    @get:JvmSynthetic
    public val badge: Badge? = null,
    @get:JvmSynthetic
    @Serializable(with = NullableStackOverflowDeserializer::class)
    public val overflow: StackComponent.Overflow? = null,
    @get:JvmSynthetic
    public val name: String? = null,
) : PartialComponent

@OptIn(InternalRevenueCatAPI::class)
internal object StackOverflowDeserializer : EnumDeserializerWithDefault<StackComponent.Overflow>(
    serialName = "com.revenuecat.purchases.paywalls.components.StackComponent.Overflow",
    valuesByType = mapOf(
        "none" to StackComponent.Overflow.NONE,
        // The schema's explicit "not scrollable" value.
        "default" to StackComponent.Overflow.NONE,
        "scroll" to StackComponent.Overflow.SCROLL,
    ),
    defaultValue = StackComponent.Overflow.NONE,
)

/** Unknown overflow values leave the stack's existing scroll behavior unchanged. */
@OptIn(InternalRevenueCatAPI::class)
internal object NullableStackOverflowDeserializer : KSerializer<StackComponent.Overflow?> {
    private val delegate = String.serializer().nullable
    override val descriptor = delegate.descriptor

    override fun deserialize(decoder: Decoder): StackComponent.Overflow? = when (delegate.deserialize(decoder)) {
        "none", "default" -> StackComponent.Overflow.NONE
        "scroll" -> StackComponent.Overflow.SCROLL
        else -> null
    }

    override fun serialize(encoder: Encoder, value: StackComponent.Overflow?) {
        throw NotImplementedError("Serialization is not implemented because it is not needed.")
    }
}
