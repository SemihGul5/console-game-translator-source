package com.revenuecat.purchases.paywalls.components.common

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.paywalls.components.properties.ThemeImageUrls
import com.revenuecat.purchases.paywalls.components.properties.ThemeVideoUrls
import com.revenuecat.purchases.utils.mapNotNullKeys
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.InternalSerializationApi
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.descriptors.PolymorphicKind
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive

/**
 * @property value The language tag of this locale, with an underscore separating the language from the region.
 */
@InternalRevenueCatAPI
@Serializable
@JvmInline
public value class LocaleId(@get:JvmSynthetic public val value: String)

@InternalRevenueCatAPI
@Serializable
@JvmInline
public value class LocalizationKey(@get:JvmSynthetic public val value: String)

/**
 * A make-shift union type. LocalizationData is either a plain String or a ThemeImageUrls object.
 */
@InternalRevenueCatAPI
@Serializable(with = LocalizationDataSerializer::class)
public sealed interface LocalizationData {
    @Serializable
    @JvmInline
    public value class Text(@get:JvmSynthetic public val value: String) : LocalizationData

    @Serializable
    @JvmInline
    public value class Image(@get:JvmSynthetic public val value: ThemeImageUrls) : LocalizationData
}

@OptIn(InternalRevenueCatAPI::class)
private object LocalizationDataSerializer : KSerializer<LocalizationData> {
    // Documentation says to use either PrimitiveSerialDescriptor or buildClassSerialDescriptor. However, we need a
    // polymorphic descriptor that's either a primitive (string) or a class. So neither of those options fit the bill.
    @OptIn(InternalSerializationApi::class, ExperimentalSerializationApi::class)
    override val descriptor: SerialDescriptor = buildSerialDescriptor(
        serialName = "LocalizationData",
        kind = PolymorphicKind.SEALED,
    )

    override fun serialize(encoder: Encoder, value: LocalizationData) {
        error("Serialization is not implemented as it is not (yet) needed.")
    }

    override fun deserialize(decoder: Decoder): LocalizationData {
        // We have no `type` descriptor field, so we look at the shape of the element instead.
        val jsonDecoder = decoder as? JsonDecoder
            ?: throw SerializationException("LocalizationData can only be deserialized from JSON.")
        val element = jsonDecoder.decodeJsonElement()
        return if (element is JsonPrimitive && element.isString) {
            LocalizationData.Text(element.content)
        } else {
            jsonDecoder.json.decodeFromJsonElement(LocalizationData.Image.serializer(), element)
        }
    }
}

/**
 * Deserializes a map of [LocaleId] to localized videos, treating `null` as having no localized videos.
 */
@InternalRevenueCatAPI
internal object LocalizedVideoMapSerializer : KSerializer<Map<LocaleId, Map<LocalizationKey, ThemeVideoUrls>>> {
    private val delegate = MapSerializer(
        keySerializer = LocaleId.serializer(),
        valueSerializer = MapSerializer(LocalizationKey.serializer(), ThemeVideoUrls.serializer()),
    )
    override val descriptor: SerialDescriptor = delegate.descriptor

    override fun serialize(encoder: Encoder, value: Map<LocaleId, Map<LocalizationKey, ThemeVideoUrls>>) {
        // Serialization is not implemented as it is not needed.
    }

    override fun deserialize(decoder: Decoder): Map<LocaleId, Map<LocalizationKey, ThemeVideoUrls>> {
        val jsonDecoder = decoder as? JsonDecoder ?: return delegate.deserialize(decoder)
        val element = jsonDecoder.decodeJsonElement()
        return if (element is JsonNull) emptyMap() else jsonDecoder.json.decodeFromJsonElement(delegate, element)
    }
}

/**
 * Deserializes a map of [LocaleId] to [VariableLocalizationKey] maps. The [VariableLocalizationKey] maps ignore unknown
 * [VariableLocalizationKey]s.
 */
@Suppress("MaxLineLength")
@InternalRevenueCatAPI
internal object LocalizedVariableLocalizationKeyMapSerializer :
    KSerializer<Map<LocaleId, Map<VariableLocalizationKey, String>>> {
    private val delegate = MapSerializer(
        keySerializer = LocaleId.serializer(),
        valueSerializer = VariableLocalizationKeyMapSerializer,
    )
    override val descriptor: SerialDescriptor = delegate.descriptor

    override fun serialize(encoder: Encoder, value: Map<LocaleId, Map<VariableLocalizationKey, String>>) {
        // Serialization is not implemented as it is not needed.
    }

    override fun deserialize(decoder: Decoder): Map<LocaleId, Map<VariableLocalizationKey, String>> =
        delegate.deserialize(decoder)
}

/**
 * Deserializes a map of [VariableLocalizationKey]s to String, ignoring unknown [VariableLocalizationKey]s.
 */
@InternalRevenueCatAPI
internal object VariableLocalizationKeyMapSerializer : KSerializer<Map<VariableLocalizationKey, String>> {
    private val delegate = MapSerializer(String.serializer(), String.serializer())

    // We can use mapSerialDescriptor<VariableLocalizationKey, String>() when that is no longer experimental. For now
    // using the delegate's descriptor is good enough, even though that has String keys.
    override val descriptor: SerialDescriptor = delegate.descriptor

    override fun serialize(encoder: Encoder, value: Map<VariableLocalizationKey, String>) {
        // Serialization is not implemented as it is not needed.
    }

    override fun deserialize(decoder: Decoder): Map<VariableLocalizationKey, String> =
        decoder.decodeSerializableValue(delegate).mapNotNullKeys { (stringKey, _) ->
            @Suppress("SwallowedException")
            try {
                VariableLocalizationKey.valueOf(stringKey.uppercase())
            } catch (e: IllegalArgumentException) {
                // Ignoring unknown VariableLocalizationKey.
                null
            }
        }
}

/**
 * Keys for localized strings used as variable values.
 */
@InternalRevenueCatAPI
@Serializable
public enum class VariableLocalizationKey {
    @SerialName("day")
    DAY,

    @SerialName("daily")
    DAILY,

    @SerialName("day_short")
    DAY_SHORT,

    @SerialName("week")
    WEEK,

    @SerialName("weekly")
    WEEKLY,

    @SerialName("week_short")
    WEEK_SHORT,

    @SerialName("month")
    MONTH,

    @SerialName("monthly")
    MONTHLY,

    @SerialName("month_short")
    MONTH_SHORT,

    @SerialName("year")
    YEAR,

    @SerialName("yearly")
    YEARLY,

    @SerialName("year_short")
    YEAR_SHORT,

    @SerialName("annual")
    ANNUAL,

    @SerialName("annually")
    ANNUALLY,

    @SerialName("annual_short")
    ANNUAL_SHORT,

    @SerialName("lifetime")
    LIFETIME,

    @SerialName("free_price")
    FREE_PRICE,

    @SerialName("percent")
    PERCENT,

    @SerialName("num_day_zero")
    NUM_DAY_ZERO,

    @SerialName("num_day_one")
    NUM_DAY_ONE,

    @SerialName("num_day_two")
    NUM_DAY_TWO,

    @SerialName("num_day_few")
    NUM_DAY_FEW,

    @SerialName("num_day_many")
    NUM_DAY_MANY,

    @SerialName("num_day_other")
    NUM_DAY_OTHER,

    @SerialName("num_week_zero")
    NUM_WEEK_ZERO,

    @SerialName("num_week_one")
    NUM_WEEK_ONE,

    @SerialName("num_week_two")
    NUM_WEEK_TWO,

    @SerialName("num_week_few")
    NUM_WEEK_FEW,

    @SerialName("num_week_many")
    NUM_WEEK_MANY,

    @SerialName("num_week_other")
    NUM_WEEK_OTHER,

    @SerialName("num_month_zero")
    NUM_MONTH_ZERO,

    @SerialName("num_month_one")
    NUM_MONTH_ONE,

    @SerialName("num_month_two")
    NUM_MONTH_TWO,

    @SerialName("num_month_few")
    NUM_MONTH_FEW,

    @SerialName("num_month_many")
    NUM_MONTH_MANY,

    @SerialName("num_month_other")
    NUM_MONTH_OTHER,

    @SerialName("num_year_zero")
    NUM_YEAR_ZERO,

    @SerialName("num_year_one")
    NUM_YEAR_ONE,

    @SerialName("num_year_two")
    NUM_YEAR_TWO,

    @SerialName("num_year_few")
    NUM_YEAR_FEW,

    @SerialName("num_year_many")
    NUM_YEAR_MANY,

    @SerialName("num_year_other")
    NUM_YEAR_OTHER,

    @SerialName("num_days_short")
    NUM_DAYS_SHORT,

    @SerialName("num_weeks_short")
    NUM_WEEKS_SHORT,

    @SerialName("num_months_short")
    NUM_MONTHS_SHORT,

    @SerialName("num_years_short")
    NUM_YEARS_SHORT,
}
