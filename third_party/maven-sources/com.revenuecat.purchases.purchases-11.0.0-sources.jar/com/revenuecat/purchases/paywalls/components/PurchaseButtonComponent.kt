package com.revenuecat.purchases.paywalls.components

import androidx.compose.runtime.Immutable
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.paywalls.components.ButtonComponent.UrlMethod
import com.revenuecat.purchases.paywalls.components.common.LocalizationKey
import com.revenuecat.purchases.utils.serializers.EnumDeserializerWithDefault
import com.revenuecat.purchases.utils.serializers.SealedDeserializerWithDefault
import dev.drewhamilton.poko.Poko
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@InternalRevenueCatAPI
@Poko
@Serializable
@SerialName("purchase_button")
@Immutable
public class PurchaseButtonComponent(
    @get:JvmSynthetic public val stack: StackComponent,
    @get:JvmSynthetic public val action: Action? = null,
    @get:JvmSynthetic public val method: Method? = null,
    @get:JvmSynthetic public val name: String? = null,
) : PaywallComponent {
    @Serializable(with = ActionDeserializer::class)
    public enum class Action {
        IN_APP_CHECKOUT,
        WEB_CHECKOUT,
        WEB_PRODUCT_SELECTION,
        ;

        public fun toMethod(): Method = when (this) {
            IN_APP_CHECKOUT -> Method.InAppCheckout
            WEB_CHECKOUT -> Method.WebCheckout()
            WEB_PRODUCT_SELECTION -> Method.WebProductSelection()
        }
    }

    @Serializable(with = PurchaseButtonMethodDeserializer::class)
    public sealed interface Method {
        @Serializable
        public object InAppCheckout : Method

        @Serializable
        @Immutable
        public data class WebCheckout(
            @SerialName("auto_dismiss")
            @get:JvmSynthetic public val autoDismiss: Boolean? = null,
            @SerialName("open_method")
            @get:JvmSynthetic public val openMethod: UrlMethod? = null,
        ) : Method

        @Serializable
        @Immutable
        public data class WebProductSelection(
            @SerialName("auto_dismiss")
            @get:JvmSynthetic public val autoDismiss: Boolean? = null,
            @SerialName("open_method")
            @get:JvmSynthetic public val openMethod: UrlMethod? = null,
        ) : Method

        @Serializable
        @Immutable
        public data class CustomWebCheckout(
            @SerialName("custom_url")
            @get:JvmSynthetic public val customUrl: CustomUrl,
            @SerialName("auto_dismiss")
            @get:JvmSynthetic public val autoDismiss: Boolean? = null,
            @SerialName("open_method")
            @get:JvmSynthetic public val openMethod: UrlMethod? = null,
        ) : Method

        @Serializable
        public object Unknown : Method
    }

    @Serializable
    @Immutable
    public data class CustomUrl(
        @SerialName("url_lid")
        public val urlLid: LocalizationKey,
        @SerialName("package_param")
        public val packageParam: String? = null,
        @SerialName("app_user_id_param")
        public val appUserIdParam: String? = null,
        @SerialName("env_param")
        public val envParam: String? = null,
    )
}

@OptIn(InternalRevenueCatAPI::class)
private object ActionDeserializer : EnumDeserializerWithDefault<PurchaseButtonComponent.Action> (
    serialName = "com.revenuecat.purchases.paywalls.components.PurchaseButtonComponent.Action",
    defaultValue = PurchaseButtonComponent.Action.IN_APP_CHECKOUT,
)

@OptIn(InternalRevenueCatAPI::class)
internal object PurchaseButtonMethodDeserializer : SealedDeserializerWithDefault<PurchaseButtonComponent.Method>(
    serialName = "Method",
    serializerByType = mapOf(
        "in_app_checkout" to { PurchaseButtonComponent.Method.InAppCheckout.serializer() },
        "web_checkout" to { PurchaseButtonComponent.Method.WebCheckout.serializer() },
        "web_product_selection" to { PurchaseButtonComponent.Method.WebProductSelection.serializer() },
        "custom_web_checkout" to { PurchaseButtonComponent.Method.CustomWebCheckout.serializer() },
    ),
    defaultValue = { PurchaseButtonComponent.Method.Unknown },
)
