package com.revenuecat.purchases.utils

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.JsonTools.json
import com.revenuecat.purchases.Offering
import com.revenuecat.purchases.PackageType
import com.revenuecat.purchases.UiConfig
import com.revenuecat.purchases.common.OfferingParser
import com.revenuecat.purchases.common.sha256
import com.revenuecat.purchases.models.Period
import com.revenuecat.purchases.models.Price
import com.revenuecat.purchases.models.PricingPhase
import com.revenuecat.purchases.models.RecurrenceMode
import com.revenuecat.purchases.models.StoreProduct
import com.revenuecat.purchases.models.TestStoreProduct
import com.revenuecat.purchases.paywalls.components.common.PaywallComponentsData
import org.json.JSONObject

/**
 * This is instantiated via reflection by revenuecatui, in `TemplatePreviews.kt`, to be able to show previews of entire
 * v2 Paywall templates.
 */
@Suppress("unused", "LongMethod")
internal class PreviewOfferingParser : OfferingParser() {

    /**
     * The SDK's parsers never capture `paywall_components` from the offerings response (components are served
     * from `/v1/config`), but template previews render offerings straight from local JSON fixtures, so this is
     * the one parser that still builds them.
     */
    @OptIn(InternalRevenueCatAPI::class)
    override fun createPaywallComponents(
        paywallComponentsJson: JSONObject?,
        uiConfig: UiConfig?,
        hasWellShaped: Boolean,
    ): Offering.PaywallComponents? {
        if (paywallComponentsJson == null || uiConfig == null || !hasWellShaped) return null

        // Defer the (potentially expensive) component-tree deserialization until the paywall is actually
        // accessed/displayed, mirroring what the production parsers did when they still captured components.
        val rawPaywallComponents = paywallComponentsJson.toString()
        return Offering.PaywallComponents(uiConfig, componentsHash = rawPaywallComponents.sha256()) {
            json.decodeFromString<PaywallComponentsData>(rawPaywallComponents)
        }
    }

    override fun findMatchingProduct(
        productsById: Map<String, List<StoreProduct>>,
        packageJson: JSONObject,
    ): StoreProduct? {
        // Ignoring productsById and just returning a product based on the identifier in the packageJson.
        val identifier = packageJson.getString("identifier")
        val packageType = PackageType.values().first { packageType -> packageType.identifier == identifier }

        // These products are the same as those in TestData in revenuecatui.
        return when (packageType) {
            PackageType.LIFETIME -> TestStoreProduct(
                id = "com.revenuecat.lifetime_product",
                name = "Lifetime",
                title = "Lifetime (App name)",
                price = Price(amountMicros = 1_000_000_000, currencyCode = "USD", formatted = "$ 1,000.00"),
                description = "Lifetime",
                period = null,
            )

            PackageType.ANNUAL -> TestStoreProduct(
                id = "com.revenuecat.annual_product",
                name = "Annual",
                title = "Annual (App name)",
                price = Price(amountMicros = 67_990_000, currencyCode = "USD", formatted = "$ 67.99"),
                description = "Annual",
                period = Period(value = 1, unit = Period.Unit.YEAR, iso8601 = "P1Y"),
                freeTrialPricingPhase = PricingPhase(
                    billingPeriod = Period(value = 1, unit = Period.Unit.MONTH, iso8601 = "P1M"),
                    recurrenceMode = RecurrenceMode.FINITE_RECURRING,
                    billingCycleCount = 1,
                    price = Price(
                        amountMicros = 0L,
                        currencyCode = "USD",
                        formatted = "Free",
                    ),
                ),
            )

            PackageType.SIX_MONTH -> TestStoreProduct(
                id = "com.revenuecat.semester_product",
                name = "6 month",
                title = "6 month (App name)",
                price = Price(amountMicros = 39_990_000, currencyCode = "USD", formatted = "$ 39.99"),
                description = "6 month",
                period = Period(value = 6, unit = Period.Unit.MONTH, iso8601 = "P6M"),
            )

            PackageType.THREE_MONTH -> TestStoreProduct(
                id = "com.revenuecat.quarterly_product",
                name = "3 month",
                title = "3 month (App name)",
                price = Price(amountMicros = 23_990_000, currencyCode = "USD", formatted = "$ 23.99"),
                description = "3 month",
                period = Period(value = 3, unit = Period.Unit.MONTH, iso8601 = "P3M"),
                freeTrialPricingPhase = PricingPhase(
                    billingPeriod = Period(value = 2, unit = Period.Unit.WEEK, iso8601 = "P2W"),
                    recurrenceMode = RecurrenceMode.FINITE_RECURRING,
                    billingCycleCount = 1,
                    price = Price(
                        amountMicros = 0L,
                        currencyCode = "USD",
                        formatted = "Free",
                    ),
                ),
                introPricePricingPhase = PricingPhase(
                    billingPeriod = Period(value = 1, unit = Period.Unit.MONTH, iso8601 = "P1M"),
                    recurrenceMode = RecurrenceMode.FINITE_RECURRING,
                    billingCycleCount = 1,
                    price = Price(amountMicros = 3_990_000, currencyCode = "USD", formatted = "$ 3.99"),
                ),
            )

            PackageType.TWO_MONTH -> TestStoreProduct(
                id = "com.revenuecat.bimonthly_product",
                name = "2 month",
                title = "2 month (App name)",
                price = Price(amountMicros = 15_990_000, currencyCode = "USD", formatted = "$ 15.99"),
                description = "2 month",
                period = Period(value = 2, unit = Period.Unit.MONTH, iso8601 = "P2M"),
                introPricePricingPhase = PricingPhase(
                    billingPeriod = Period(value = 1, unit = Period.Unit.MONTH, iso8601 = "P1M"),
                    recurrenceMode = RecurrenceMode.FINITE_RECURRING,
                    billingCycleCount = 1,
                    price = Price(amountMicros = 3_990_000, currencyCode = "USD", formatted = "$ 3.99"),
                ),
            )

            PackageType.MONTHLY -> TestStoreProduct(
                id = "com.revenuecat.monthly_product",
                name = "Monthly",
                title = "Monthly (App name)",
                price = Price(amountMicros = 7_990_000, currencyCode = "USD", formatted = "$ 7.99"),
                description = "Monthly",
                period = Period(value = 1, unit = Period.Unit.MONTH, iso8601 = "P1M"),
            )

            PackageType.WEEKLY -> TestStoreProduct(
                id = "com.revenuecat.weekly_product",
                name = "Weekly",
                title = "Weekly (App name)",
                price = Price(amountMicros = 1_490_000, currencyCode = "USD", formatted = "$ 1.49"),
                description = "Weekly",
                period = Period(value = 1, unit = Period.Unit.WEEK, iso8601 = "P1W"),
            )

            else -> null
        }
    }
}
