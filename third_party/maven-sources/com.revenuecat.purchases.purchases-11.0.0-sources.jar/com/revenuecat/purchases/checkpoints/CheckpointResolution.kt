package com.revenuecat.purchases.checkpoints

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.Offering
import com.revenuecat.purchases.Offerings
import com.revenuecat.purchases.UiConfig
import com.revenuecat.purchases.common.workflows.PublishedWorkflow

/**
 * What a checkpoint resolves to. Exposed to the RevenueCat UI module, which owns the checkpoints API and
 * presents the resolved workflow; never part of the SDK's public surface.
 */
@InternalRevenueCatAPI
public sealed class CheckpointResolution {

    /**
     * The checkpoint selected [offering] without requiring RevenueCat-managed UI.
     *
     * [checkpointRuleId] identifies the rule that was served, for the hit event to attribute. It is null when
     * the rules topic did not carry an id for that rule.
     *
     * [traceId] is shared by the hit event and the purchase contexts of [offering], so they can be joined.
     */
    public data class MatchedOffering(
        val offering: Offering,
        val checkpointRuleId: String?,
        val traceId: String,
    ) : CheckpointResolution()

    /**
     * The checkpoint matched [workflow]. Each step resolves the offering it presents from [offerings] when it is
     * reached; a step whose offering is missing fails at presentation time, not here.
     *
     * [checkpointRuleId] identifies the rule that was served, for the hit event to attribute. It is null when
     * the rules topic did not carry an id for that rule.
     *
     * [traceId] is shared by the hit event and every event of the workflow run, so they can be joined.
     *
     * [workflowBlobRef] identifies the exact workflow blob that was served, for the workflow run's events to
     * attribute fallback steps and experiments against. It is null when it could not be read.
     */
    public data class MatchedWorkflow(
        val workflow: PublishedWorkflow,
        val uiConfig: UiConfig,
        val offerings: Offerings,
        val checkpointRuleId: String?,
        val traceId: String,
        val workflowBlobRef: String?,
    ) : CheckpointResolution()

    /** Nothing should be served for this checkpoint; the user continues uninterrupted. */
    public data class NoAction(val reason: Reason) : CheckpointResolution() {

        public enum class Reason {
            /** The checkpoint is configured, but no rule matched. */
            NO_MATCH,

            /** The configuration needed to serve the checkpoint could not be read. */
            CONFIGURATION_UNAVAILABLE,

            /** The identifier is not configured in the RevenueCat dashboard. */
            UNKNOWN_CHECKPOINT,
        }
    }
}
