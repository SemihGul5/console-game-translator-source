//  Purchases
//
//  Copyright © 2019 RevenueCat, Inc. All rights reserved.
//

package com.revenuecat.purchases.common

import androidx.annotation.VisibleForTesting
import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.PostReceiptInitiationSource
import com.revenuecat.purchases.PurchasesAreCompletedBy
import com.revenuecat.purchases.PurchasesError
import com.revenuecat.purchases.PurchasesErrorCode
import com.revenuecat.purchases.RewardVerificationError
import com.revenuecat.purchases.RewardVerificationPollStatus
import com.revenuecat.purchases.backendName
import com.revenuecat.purchases.common.caching.WorkflowMetadata
import com.revenuecat.purchases.common.events.EventsRequest
import com.revenuecat.purchases.common.networking.Endpoint
import com.revenuecat.purchases.common.networking.HTTPRequest
import com.revenuecat.purchases.common.networking.HTTPResult
import com.revenuecat.purchases.common.networking.PostReceiptResponse
import com.revenuecat.purchases.common.networking.RCContainer
import com.revenuecat.purchases.common.networking.RCContainerFormatException
import com.revenuecat.purchases.common.networking.RCHTTPStatusCodes
import com.revenuecat.purchases.common.networking.RewardVerificationResponse
import com.revenuecat.purchases.common.networking.WebBillingProductsResponse
import com.revenuecat.purchases.common.networking.buildPostReceiptResponse
import com.revenuecat.purchases.common.offlineentitlements.ProductEntitlementMapping
import com.revenuecat.purchases.common.remoteconfig.RemoteConfigFetchContext
import com.revenuecat.purchases.common.remoteconfig.RemoteConfiguration
import com.revenuecat.purchases.common.verification.SignatureVerificationMode
import com.revenuecat.purchases.common.verification.SignatureVerificationResult
import com.revenuecat.purchases.customercenter.CustomerCenterConfigData
import com.revenuecat.purchases.customercenter.CustomerCenterRoot
import com.revenuecat.purchases.interfaces.RedeemWebPurchaseListener
import com.revenuecat.purchases.models.PricingPhase
import com.revenuecat.purchases.paywalls.events.PaywallPostReceiptData
import com.revenuecat.purchases.strings.NetworkStrings
import com.revenuecat.purchases.utils.asMap
import com.revenuecat.purchases.utils.filterNotNullValues
import com.revenuecat.purchases.virtualcurrencies.VirtualCurrencies
import com.revenuecat.purchases.virtualcurrencies.VirtualCurrenciesFactory
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.encodeToJsonElement
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URL
import java.util.Date
import java.util.UUID

internal const val ATTRIBUTES_ERROR_RESPONSE_KEY = "attributes_error_response"
internal const val ATTRIBUTE_ERRORS_KEY = "attribute_errors"

/** @suppress */
internal typealias CustomerInfoCallback = Pair<(CustomerInfo) -> Unit, (PurchasesError, isServerError: Boolean) -> Unit>

/** @suppress */
internal typealias PostReceiptCallback = Pair<PostReceiptDataSuccessCallback, PostReceiptDataErrorCallback>

/** @suppress */
internal typealias CallbackCacheKey = List<String>

/** @suppress */
@OptIn(InternalRevenueCatAPI::class)
internal typealias OfferingsSuccessCallback = (JSONObject, HTTPResponseOriginalSource, responsePayload: String) -> Unit

/** @suppress */
@OptIn(InternalRevenueCatAPI::class)
internal typealias OfferingsCallback = Pair<
    OfferingsSuccessCallback,
    (PurchasesError, errorHandlingBehavior: GetOfferingsErrorHandlingBehavior) -> Unit,
    >

/** @suppress */
internal typealias PostReceiptDataSuccessCallback = (PostReceiptResponse) -> Unit

/** @suppress */
internal typealias PostReceiptDataErrorCallback = (
    PurchasesError,
    postReceiptErrorHandlingBehavior: PostReceiptErrorHandlingBehavior,
    body: JSONObject?,
) -> Unit

/** @suppress */
internal typealias IdentifyCallback = Pair<(CustomerInfo, Boolean) -> Unit, (PurchasesError) -> Unit>

/** @suppress */
internal typealias AliasCallback = Pair<() -> Unit, (PurchasesError) -> Unit>

/** @suppress */
internal typealias DiagnosticsCallback = Pair<(JSONObject) -> Unit, (PurchasesError, Boolean) -> Unit>

/** @suppress */
internal typealias PaywallEventsCallback = Pair<() -> Unit, (PurchasesError, Boolean) -> Unit>

/** @suppress */
@OptIn(InternalRevenueCatAPI::class)
internal typealias ProductEntitlementCallback = Pair<(ProductEntitlementMapping) -> Unit, (PurchasesError) -> Unit>

@OptIn(InternalRevenueCatAPI::class)
internal typealias CustomerCenterCallback = Pair<(CustomerCenterConfigData) -> Unit, (PurchasesError) -> Unit>

internal typealias CreateSupportTicketCallback = Pair<(Boolean) -> Unit, (PurchasesError) -> Unit>

internal typealias RedeemWebPurchaseCallback = (RedeemWebPurchaseListener.Result) -> Unit

internal typealias VirtualCurrenciesCallback = Pair<(VirtualCurrencies) -> Unit, (PurchasesError) -> Unit>

internal typealias WebBillingProductsCallback = Pair<(WebBillingProductsResponse) -> Unit, (PurchasesError) -> Unit>

@OptIn(InternalRevenueCatAPI::class)
internal typealias RewardVerificationResultCallback =
    Pair<(RewardVerificationPollStatus) -> Unit, (RewardVerificationError) -> Unit>

internal typealias RemoteConfigCallback = Pair<
    (RCContainer?, requestDate: Date?, SignatureVerificationResult) -> Unit,
    (PurchasesError, errorHandlingBehavior: GetRemoteConfigErrorHandlingBehavior) -> Unit,
    >

internal typealias RemoteConfigFallbackCallback = Pair<
    (RemoteConfiguration, SignatureVerificationResult) -> Unit,
    (PurchasesError) -> Unit,
    >

internal enum class PostReceiptErrorHandlingBehavior {
    SHOULD_BE_MARKED_SYNCED,
    SHOULD_USE_OFFLINE_ENTITLEMENTS_AND_NOT_CONSUME,
    SHOULD_NOT_CONSUME,
}

internal enum class GetOfferingsErrorHandlingBehavior {
    SHOULD_FALLBACK_TO_CACHED_OFFERINGS,
    SHOULD_NOT_FALLBACK,
}

internal enum class GetRemoteConfigErrorHandlingBehavior {
    // 5xx, transport, or parse failures: the endpoint may recover, so a cold start may try the fallback endpoint.
    SHOULD_RETRY,

    // A 4xx client error: the endpoint intentionally refused the request (bad shape, feature not provisioned,
    // auth rejection), so the fallback endpoint would refuse it too. The next scheduled sync still retries.
    SHOULD_NOT_TRY_FALLBACK,
}

@OptIn(InternalRevenueCatAPI::class)
@Suppress("TooManyFunctions")
internal class Backend(
    private val appConfig: AppConfig,
    private val dispatcher: Dispatcher,
    private val eventsDispatcher: Dispatcher,
    private val httpClient: HTTPClient,
    private val backendHelper: BackendHelper,
    private val remoteConfigDispatcher: Dispatcher = dispatcher,
) {
    companion object {
        private const val APP_USER_ID = "app_user_id"
        private const val FETCH_TOKEN = "fetch_token"
        private const val NEW_APP_USER_ID = "new_app_user_id"

        /**
         * This version should be bumped whenever there is a change to the payload of POST receipt that the backend
         * may need to handle differently. It should be kept in sync with the iOS SDK.
         */
        private const val POST_RECEIPT_PAYLOAD_VERSION = 1

        @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
        internal val json = Json {
            ignoreUnknownKeys = true
        }
    }

    val verificationMode: SignatureVerificationMode
        get() = httpClient.signingManager.signatureVerificationMode

    @get:Synchronized @set:Synchronized
    @Volatile var callbacks = mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<CustomerInfoCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var postReceiptCallbacks = mutableMapOf<CallbackCacheKey, MutableList<PostReceiptCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var offeringsCallbacks =
        mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<OfferingsCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var identifyCallbacks = mutableMapOf<CallbackCacheKey, MutableList<IdentifyCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var aliasCallbacks = mutableMapOf<CallbackCacheKey, MutableList<AliasCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var diagnosticsCallbacks = mutableMapOf<CallbackCacheKey, MutableList<DiagnosticsCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var paywallEventsCallbacks = mutableMapOf<CallbackCacheKey, MutableList<PaywallEventsCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var productEntitlementCallbacks = mutableMapOf<String, MutableList<ProductEntitlementCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var customerCenterCallbacks = mutableMapOf<String, MutableList<CustomerCenterCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var createSupportTicketCallbacks = mutableMapOf<String, MutableList<CreateSupportTicketCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var redeemWebPurchaseCallbacks = mutableMapOf<String, MutableList<RedeemWebPurchaseCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var virtualCurrenciesCallbacks =
        mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<VirtualCurrenciesCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var webBillingProductsCallbacks = mutableMapOf<String, MutableList<WebBillingProductsCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var rewardVerificationResultCallbacks =
        mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<RewardVerificationResultCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var remoteConfigCallbacks =
        mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<RemoteConfigCallback>>()

    @get:Synchronized @set:Synchronized
    @Volatile var remoteConfigFallbackCallbacks =
        mutableMapOf<BackgroundAwareCallbackCacheKey, MutableList<RemoteConfigFallbackCallback>>()

    fun close() {
        this.dispatcher.close()
        this.remoteConfigDispatcher.close()
    }

    fun getCustomerInfo(
        appUserID: String,
        appInBackground: Boolean,
        onSuccess: (CustomerInfo) -> Unit,
        onError: (PurchasesError, isServerError: Boolean) -> Unit,
    ) {
        val endpoint = Endpoint.GetCustomerInfo(appUserID)
        val path = endpoint.getPath()
        val cacheKey = synchronized(this@Backend) {
            // If there is any enqueued `postReceiptData` we don't want this new
            // `getCustomerInfo` to share the same cache key.
            // If it did, future `getCustomerInfo` would receive a cached value
            // instead of an up-to-date `CustomerInfo` after those post receipt operations finish.
            if (postReceiptCallbacks.isEmpty()) {
                BackgroundAwareCallbackCacheKey(listOf(path), appInBackground)
            } else {
                BackgroundAwareCallbackCacheKey(listOf(path) + "${callbacks.count()}", appInBackground)
            }
        }
        val call = object : Dispatcher.AsyncCall() {

            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    callbacks.remove(cacheKey)
                }?.forEach { (onSuccess, onError) ->
                    try {
                        if (result.isSuccessful()) {
                            onSuccess(CustomerInfoFactory.buildCustomerInfo(result))
                        } else {
                            onError(
                                result.toPurchasesError().also { errorLog(it) },
                                RCHTTPStatusCodes.isServerError(result.responseCode),
                            )
                        }
                    } catch (e: JSONException) {
                        val isServerError = false
                        onError(e.toPurchasesError().also { errorLog(it) }, isServerError)
                    }
                }
            }

            override fun onError(error: PurchasesError) {
                val isServerError = false
                synchronized(this@Backend) {
                    callbacks.remove(cacheKey)
                }?.forEach { (_, onError) ->
                    onError(error, isServerError)
                }
            }
        }
        synchronized(this@Backend) {
            val delay = Delay.jitterOnlyIfInBackground(appInBackground)
            callbacks.addBackgroundAwareCallback(call, dispatcher, cacheKey, onSuccess to onError, delay)
        }
    }

    @SuppressWarnings("LongParameterList", "ForbiddenComment")
    fun postReceiptData(
        purchaseToken: String,
        appUserID: String,
        isRestore: Boolean,
        finishTransactions: Boolean,
        subscriberAttributes: Map<String, Map<String, Any?>>,
        receiptInfo: ReceiptInfo,
        initiationSource: PostReceiptInitiationSource,
        paywallPostReceiptData: PaywallPostReceiptData?,
        workflowMetadata: WorkflowMetadata? = null,
        // This reflects the value at the time of the purchase, which might come from the LocalTransactionMetadataStore
        purchasesAreCompletedBy: PurchasesAreCompletedBy,
        onSuccess: PostReceiptDataSuccessCallback,
        onError: PostReceiptDataErrorCallback,
    ) {
        val cacheKey = listOfNotNull(
            purchaseToken,
            appUserID,
            isRestore.toString(),
            finishTransactions.toString(),
            subscriberAttributes.toString(),
            receiptInfo.toString(),
            purchasesAreCompletedBy.toString(),
        )

        val body = mapOf(
            FETCH_TOKEN to purchaseToken,
            "product_ids" to receiptInfo.productIDs,
            "platform_product_ids" to receiptInfo.platformProductIds,
            APP_USER_ID to appUserID,
            "is_restore" to isRestore,
            "presented_offering_identifier" to receiptInfo.presentedOfferingContext?.offeringIdentifier,
            "presented_placement_identifier" to receiptInfo.presentedOfferingContext?.placementIdentifier,
            "presented_checkpoint_identifier" to receiptInfo.presentedOfferingContext?.checkpointIdentifier,
            "presented_trace_id" to receiptInfo.presentedOfferingContext?.traceId,
            "applied_targeting_rule" to receiptInfo.presentedOfferingContext?.targetingContext?.let {
                return@let mapOf("revision" to it.revision, "rule_id" to it.ruleId)
            },
            "observer_mode" to !finishTransactions,
            "purchase_completed_by" to purchasesAreCompletedBy.name.lowercase(),
            "price" to receiptInfo.price,
            "currency" to receiptInfo.currency,
            "attributes" to subscriberAttributes.takeUnless { it.isEmpty() || appConfig.customEntitlementComputation },
            "normal_duration" to receiptInfo.duration,
            "store_user_id" to receiptInfo.storeUserID,
            "pricing_phases" to receiptInfo.pricingPhases?.map { it.toMap() },
            "proration_mode" to receiptInfo.replacementMode?.backendName(store = appConfig.store),
            "initiation_source" to initiationSource.postReceiptFieldValue,
            "paywall" to paywallPostReceiptData?.toMap(),
            "presented_workflow_id" to workflowMetadata?.workflowId,
            "presented_step_id" to workflowMetadata?.stepId,
            "sdk_originated" to receiptInfo.sdkOriginated,
            "payload_version" to POST_RECEIPT_PAYLOAD_VERSION,
        ).filterNotNullValues()

        val postFieldsToSign = listOf(
            APP_USER_ID to appUserID,
            FETCH_TOKEN to purchaseToken,
        )

        val extraHeaders = mapOf(
            "price_string" to receiptInfo.formattedPrice,
            "marketplace" to receiptInfo.marketplace,
        ).filterNotNullValues()

        val call = object : Dispatcher.AsyncCall() {

            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    Endpoint.PostReceipt,
                    body,
                    postFieldsToSign,
                    backendHelper.authenticationHeaders + extraHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    postReceiptCallbacks.remove(cacheKey)
                }?.forEach { (onSuccess, onError) ->
                    try {
                        if (result.isSuccessful()) {
                            onSuccess(buildPostReceiptResponse(result))
                        } else {
                            val purchasesError = result.toPurchasesError().also { errorLog(it) }
                            val errorHandlingBehavior = determinePostReceiptErrorHandlingBehavior(
                                result.responseCode,
                                purchasesError,
                            )
                            onError(
                                purchasesError,
                                errorHandlingBehavior,
                                result.body,
                            )
                        }
                    } catch (e: JSONException) {
                        onError(
                            e.toPurchasesError().also { errorLog(it) },
                            PostReceiptErrorHandlingBehavior.SHOULD_NOT_CONSUME,
                            null,
                        )
                    }
                }
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    postReceiptCallbacks.remove(cacheKey)
                }?.forEach { (_, onError) ->
                    onError(
                        error,
                        PostReceiptErrorHandlingBehavior.SHOULD_NOT_CONSUME,
                        null,
                    )
                }
            }
        }
        synchronized(this@Backend) {
            postReceiptCallbacks.addCallback(call, dispatcher, cacheKey, onSuccess to onError)
        }
    }

    fun getOfferings(
        appUserID: String,
        appInBackground: Boolean,
        onSuccess: OfferingsSuccessCallback,
        onError: (PurchasesError, GetOfferingsErrorHandlingBehavior) -> Unit,
    ) {
        val endpoint = Endpoint.GetOfferings(appUserID)
        val path = endpoint.getPath()
        val cacheKey = BackgroundAwareCallbackCacheKey(listOf(path), appInBackground)
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    offeringsCallbacks.remove(cacheKey)
                }?.forEach { (_, onError) ->
                    onError(error, GetOfferingsErrorHandlingBehavior.SHOULD_FALLBACK_TO_CACHED_OFFERINGS)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    offeringsCallbacks.remove(cacheKey)
                }?.forEach { (onSuccess, onError) ->
                    if (result.isSuccessful()) {
                        try {
                            onSuccess(result.body, result.originalDataSource, result.payloadText)
                        } catch (e: JSONException) {
                            val errorBehavior = GetOfferingsErrorHandlingBehavior.SHOULD_FALLBACK_TO_CACHED_OFFERINGS
                            onError(e.toPurchasesError().also { errorLog(it) }, errorBehavior)
                        }
                    } else {
                        val errorBehavior = if (RCHTTPStatusCodes.isServerError(result.responseCode)) {
                            GetOfferingsErrorHandlingBehavior.SHOULD_FALLBACK_TO_CACHED_OFFERINGS
                        } else {
                            GetOfferingsErrorHandlingBehavior.SHOULD_NOT_FALLBACK
                        }
                        onError(
                            result.toPurchasesError().also { errorLog(it) },
                            errorBehavior,
                        )
                    }
                }
            }
        }
        synchronized(this@Backend) {
            val delay = Delay.jitterOnlyIfInBackground(appInBackground)
            offeringsCallbacks.addBackgroundAwareCallback(call, dispatcher, cacheKey, onSuccess to onError, delay)
        }
    }

    fun logIn(
        appUserID: String,
        newAppUserID: String,
        onSuccessHandler: (CustomerInfo, Boolean) -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val cacheKey = listOfNotNull(
            appUserID,
            newAppUserID,
        )
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                val body = mapOf(
                    APP_USER_ID to appUserID,
                    NEW_APP_USER_ID to newAppUserID,
                )
                val postFieldsToSign = listOf(
                    APP_USER_ID to appUserID,
                    NEW_APP_USER_ID to newAppUserID,
                )
                return httpClient.performRequest(
                    appConfig.baseURL,
                    Endpoint.LogIn,
                    body,
                    postFieldsToSign,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    identifyCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                if (result.isSuccessful()) {
                    synchronized(this@Backend) {
                        identifyCallbacks.remove(cacheKey)
                    }?.forEach { (onSuccessHandler, onErrorHandler) ->
                        val created = result.responseCode == RCHTTPStatusCodes.CREATED
                        if (result.body.length() > 0) {
                            val customerInfo = CustomerInfoFactory.buildCustomerInfo(result)
                            onSuccessHandler(customerInfo, created)
                        } else {
                            onErrorHandler(
                                PurchasesError(PurchasesErrorCode.UnknownError)
                                    .also { errorLog(it) },
                            )
                        }
                    }
                } else {
                    onError(result.toPurchasesError().also { errorLog(it) })
                }
            }
        }
        synchronized(this@Backend) {
            identifyCallbacks.addCallback(call, dispatcher, cacheKey, onSuccessHandler to onErrorHandler)
        }
    }

    fun aliasUsers(
        oldAppUserID: String,
        newAppUserID: String,
        onSuccessHandler: () -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val cacheKey = listOfNotNull(
            oldAppUserID,
            newAppUserID,
        )
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                val body = mapOf(
                    APP_USER_ID to oldAppUserID,
                    NEW_APP_USER_ID to newAppUserID,
                )
                return httpClient.performRequest(
                    appConfig.baseURL,
                    Endpoint.AliasUsers(oldAppUserID),
                    body,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = oldAppUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    aliasCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                if (result.isSuccessful()) {
                    synchronized(this@Backend) {
                        aliasCallbacks.remove(cacheKey)
                    }?.forEach { (onSuccessHandler, _) ->
                        onSuccessHandler()
                    }
                } else {
                    onError(result.toPurchasesError().also { errorLog(it) })
                }
            }
        }
        synchronized(this@Backend) {
            aliasCallbacks.addCallback(call, dispatcher, cacheKey, onSuccessHandler to onErrorHandler)
        }
    }

    fun postDiagnostics(
        diagnosticsList: List<JSONObject>,
        onSuccessHandler: (JSONObject) -> Unit,
        onErrorHandler: (PurchasesError, Boolean) -> Unit,
    ) {
        val cacheKey = diagnosticsList.map { it.hashCode().toString() }

        val body = mapOf("entries" to JSONArray(diagnosticsList))
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    AppConfig.diagnosticsURL,
                    Endpoint.PostDiagnostics,
                    body,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    diagnosticsCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error, error.code == PurchasesErrorCode.NetworkError)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    diagnosticsCallbacks.remove(cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        onSuccessHandler(result.body)
                    } else {
                        val error = result.toPurchasesError()
                        val shouldRetry = RCHTTPStatusCodes.isServerError(result.responseCode) ||
                            error.code == PurchasesErrorCode.NetworkError
                        onErrorHandler(error, shouldRetry)
                    }
                }
            }
        }
        synchronized(this@Backend) {
            diagnosticsCallbacks.addCallback(
                call,
                eventsDispatcher,
                cacheKey,
                onSuccessHandler to onErrorHandler,
                Delay.LONG,
            )
        }
    }

    fun postEvents(
        paywallEventRequest: EventsRequest,
        baseURL: URL,
        delay: Delay,
        onSuccessHandler: () -> Unit,
        onErrorHandler: (error: PurchasesError, shouldMarkAsSynced: Boolean) -> Unit,
    ) {
        val body = JsonProvider.defaultJson.encodeToJsonElement(paywallEventRequest).asMap()
        if (body == null) {
            onErrorHandler(
                PurchasesError(
                    PurchasesErrorCode.UnknownError,
                    "Error encoding paywall event request",
                ).also { errorLog(it) },
                true,
            )
            return
        }
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    baseURL,
                    Endpoint.PostEvents,
                    body,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    paywallEventsCallbacks.remove(paywallEventRequest.cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error, false)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    paywallEventsCallbacks.remove(paywallEventRequest.cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        onSuccessHandler()
                    } else {
                        onErrorHandler(result.toPurchasesError(), RCHTTPStatusCodes.isSynced(result.responseCode))
                    }
                }
            }
        }
        synchronized(this@Backend) {
            paywallEventsCallbacks.addCallback(
                call,
                eventsDispatcher,
                paywallEventRequest.cacheKey,
                onSuccessHandler to onErrorHandler,
                delay,
            )
        }
    }

    fun getProductEntitlementMapping(
        onSuccessHandler: (ProductEntitlementMapping) -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val endpoint = Endpoint.GetProductEntitlementMapping
        val path = endpoint.getPath()
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    productEntitlementCallbacks.remove(path)
                }?.forEach { (_, onError) ->
                    onError(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    productEntitlementCallbacks.remove(path)
                }?.forEach { (onSuccess, onError) ->
                    if (result.isSuccessful()) {
                        try {
                            onSuccess(ProductEntitlementMapping.fromNetwork(result.body, result))
                        } catch (e: JSONException) {
                            onError(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onError(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }
        synchronized(this@Backend) {
            productEntitlementCallbacks.addCallback(
                call,
                dispatcher,
                path,
                onSuccessHandler to onErrorHandler,
                Delay.LONG,
            )
        }
    }

    fun getCustomerCenterConfig(
        appUserID: String,
        onSuccessHandler: (CustomerCenterConfigData) -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val endpoint = Endpoint.GetCustomerCenterConfig(appUserID)
        val path = endpoint.getPath()
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    customerCenterCallbacks.remove(path)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    customerCenterCallbacks.remove(path)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            val customerCenterRoot = json.decodeFromString<CustomerCenterRoot>(
                                result.payloadText,
                            )
                            onSuccessHandler(customerCenterRoot.customerCenter)
                        } catch (e: SerializationException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        } catch (e: IllegalArgumentException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }
        synchronized(this@Backend) {
            customerCenterCallbacks.addCallback(
                call,
                dispatcher,
                path,
                onSuccessHandler to onErrorHandler,
                Delay.NONE,
            )
        }
    }

    fun postCreateSupportTicket(
        appUserID: String,
        email: String,
        description: String,
        onSuccessHandler: (Boolean) -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val endpoint = Endpoint.PostCreateSupportTicket
        val path = endpoint.getPath()
        val body = mapOf(
            APP_USER_ID to appUserID,
            "customer_email" to email,
            "issue_description" to description,
        )
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    createSupportTicketCallbacks.remove(path)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    createSupportTicketCallbacks.remove(path)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            val wasSent = result.body.optBoolean("sent", false)
                            onSuccessHandler(wasSent)
                        } catch (e: SerializationException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        } catch (e: IllegalArgumentException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }
        synchronized(this@Backend) {
            createSupportTicketCallbacks.addCallback(
                call,
                dispatcher,
                path,
                onSuccessHandler to onErrorHandler,
                Delay.NONE,
            )
        }
    }

    @Suppress("NestedBlockDepth")
    fun postRedeemWebPurchase(
        appUserID: String,
        redemptionToken: String,
        onResultHandler: (RedeemWebPurchaseListener.Result) -> Unit,
    ) {
        val endpoint = Endpoint.PostRedeemWebPurchase
        val path = endpoint.getPath()
        val body = mapOf("redemption_token" to redemptionToken, APP_USER_ID to appUserID)
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    redeemWebPurchaseCallbacks.remove(path)
                }?.forEach { callback ->
                    callback(RedeemWebPurchaseListener.Result.Error(error))
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    redeemWebPurchaseCallbacks.remove(path)
                }?.forEach { callback ->
                    if (result.isSuccessful()) {
                        callback(
                            RedeemWebPurchaseListener.Result.Success(CustomerInfoFactory.buildCustomerInfo(result)),
                        )
                    } else {
                        when (result.backendErrorCode) {
                            BackendErrorCode.BackendInvalidWebRedemptionToken.value -> {
                                callback(RedeemWebPurchaseListener.Result.InvalidToken)
                            }
                            BackendErrorCode.BackendExpiredWebRedemptionToken.value -> {
                                val resultBody = result.body
                                val redemptionError = resultBody.optJSONObject("purchase_redemption_error_info")
                                val obfuscatedEmail = redemptionError?.optString("obfuscated_email")
                                if (obfuscatedEmail == null) {
                                    errorLog { "Error parsing expired redemption token response: $resultBody" }
                                    callback(RedeemWebPurchaseListener.Result.Error(result.toPurchasesError()))
                                } else {
                                    callback(RedeemWebPurchaseListener.Result.Expired(obfuscatedEmail))
                                }
                            }
                            BackendErrorCode.BackendPurchaseBelongsToOtherUser.value -> {
                                callback(RedeemWebPurchaseListener.Result.PurchaseBelongsToOtherUser)
                            }
                            else -> {
                                callback(RedeemWebPurchaseListener.Result.Error(result.toPurchasesError()))
                            }
                        }
                    }
                }
            }
        }
        synchronized(this@Backend) {
            redeemWebPurchaseCallbacks.addCallback(
                call,
                dispatcher,
                path,
                onResultHandler,
                Delay.NONE,
            )
        }
    }

    fun getVirtualCurrencies(
        appUserID: String,
        appInBackground: Boolean,
        onSuccess: (VirtualCurrencies) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        val endpoint = Endpoint.GetVirtualCurrencies(userId = appUserID)
        val path = endpoint.getPath()
        val cacheKey = BackgroundAwareCallbackCacheKey(listOf(path), appInBackground)

        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    virtualCurrenciesCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    virtualCurrenciesCallbacks.remove(cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            val virtualCurrencies = VirtualCurrenciesFactory.buildVirtualCurrencies(
                                httpResult = result,
                            )
                            onSuccessHandler(virtualCurrencies)
                        } catch (e: JSONException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        } catch (e: SerializationException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        } catch (e: IllegalArgumentException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }

        synchronized(this@Backend) {
            val delay = Delay.jitterOnlyIfInBackground(appInBackground)
            virtualCurrenciesCallbacks.addBackgroundAwareCallback(
                call,
                dispatcher,
                cacheKey,
                onSuccess to onError,
                delay,
            )
        }
    }

    // Not deduplicated: each spend is a separate transaction, keyed by its own Idempotency-Key across retries.
    fun spendVirtualCurrencies(
        appUserID: String,
        amounts: Map<String, Int>,
        reference: String?,
        onSuccessHandler: (VirtualCurrencies) -> Unit,
        onErrorHandler: (PurchasesError) -> Unit,
    ) {
        val body = buildMap<String, Any?> {
            put("adjustments", amounts)
            reference?.let { put("reference", it) }
        }
        val headers = backendHelper.authenticationHeaders + ("Idempotency-Key" to UUID.randomUUID().toString())
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult = httpClient.performRequest(
                appConfig.baseURL,
                Endpoint.SpendVirtualCurrencies,
                body,
                postFieldsToSign = null,
                headers,
                fallbackBaseURLs = appConfig.fallbackBaseURLs,
                iamAppUserID = appUserID,
            )

            override fun onError(error: PurchasesError) {
                onErrorHandler(error)
            }

            override fun onCompletion(result: HTTPResult) {
                if (!result.isSuccessful()) {
                    onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    return
                }
                try {
                    onSuccessHandler(VirtualCurrenciesFactory.buildVirtualCurrencies(httpResult = result))
                } catch (e: JSONException) {
                    onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                } catch (e: SerializationException) {
                    onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                } catch (e: IllegalArgumentException) {
                    onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                }
            }
        }
        backendHelper.enqueue(call, dispatcher)
    }

    fun getWebBillingProducts(
        appUserID: String,
        productIds: Set<String>,
        onSuccess: (WebBillingProductsResponse) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        val endpoint = Endpoint.WebBillingGetProducts(appUserID, productIds)
        val path = endpoint.getPath()
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    webBillingProductsCallbacks.remove(path)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    webBillingProductsCallbacks.remove(path)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            val productsResponse = json.decodeFromString<WebBillingProductsResponse>(
                                result.payloadText,
                            )
                            onSuccessHandler(productsResponse)
                        } catch (e: SerializationException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        } catch (e: IllegalArgumentException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }
        synchronized(this@Backend) {
            webBillingProductsCallbacks.addCallback(
                call,
                dispatcher,
                path,
                onSuccess to onError,
                Delay.NONE,
            )
        }
    }

    fun getRewardVerificationResult(
        appUserID: String,
        clientTransactionId: String,
        adUnitId: String?,
        onSuccess: (RewardVerificationPollStatus) -> Unit,
        onError: (RewardVerificationError) -> Unit,
    ) {
        val endpoint = Endpoint.GetRewardVerification(
            userId = appUserID,
            clientTransactionId = clientTransactionId,
            adUnitId = adUnitId,
        )
        val path = endpoint.getPath()
        val cacheKey = BackgroundAwareCallbackCacheKey(listOf(path), appInBackground = false)
        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    appConfig.baseURL,
                    endpoint,
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                    fallbackBaseURLs = appConfig.fallbackBaseURLs,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    rewardVerificationResultCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(RewardVerificationError(error, isServerError = false))
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    rewardVerificationResultCallbacks.remove(cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            val response = json.decodeFromString<RewardVerificationResponse>(
                                result.payloadText,
                            )
                            onSuccessHandler(response.toRewardVerificationPollStatus())
                        } catch (e: SerializationException) {
                            onErrorHandler(
                                RewardVerificationError(e.toPurchasesError().also { errorLog(it) }, false),
                            )
                        } catch (e: IllegalArgumentException) {
                            onErrorHandler(
                                RewardVerificationError(e.toPurchasesError().also { errorLog(it) }, false),
                            )
                        }
                    } else {
                        onErrorHandler(
                            RewardVerificationError(
                                result.toPurchasesError().also { errorLog(it) },
                                isServerError = RCHTTPStatusCodes.isServerError(result.responseCode),
                            ),
                        )
                    }
                }
            }
        }

        synchronized(this@Backend) {
            rewardVerificationResultCallbacks.addBackgroundAwareCallback(
                call,
                dispatcher,
                cacheKey,
                onSuccess to onError,
                Delay.NONE,
            )
        }
    }

    @Suppress("LongParameterList")
    fun getRemoteConfig(
        appInBackground: Boolean,
        appUserID: String,
        fetchContext: RemoteConfigFetchContext,
        domain: String,
        manifest: String?,
        lastRefreshTime: Date?,
        prefetchedBlobs: List<String>,
        // The server's own request time, so the caller can replay it rather than a device-clock value.
        onSuccess: (RCContainer?, Date?, SignatureVerificationResult) -> Unit,
        onError: (PurchasesError, GetRemoteConfigErrorHandlingBehavior) -> Unit,
    ) {
        val endpoint = Endpoint.GetRemoteConfig(domain)
        val path = endpoint.getPath()
        // Include the app user in the key: the path carries the domain but not the app_user_id (sent in the
        // request body), so concurrent calls for different users must not be deduped onto a single shared request.
        val cacheKey = BackgroundAwareCallbackCacheKey(listOf(path, appUserID), appInBackground)

        val baseURL = appConfig.baseURL
        // The manifest is an opaque token replayed verbatim; omitted on the first run when there is none.
        val body = buildMap<String, Any?> {
            put(APP_USER_ID, appUserID)
            put("fetch_context", fetchContext.wireName)
            manifest?.let { put("manifest", it) }
            put("prefetched_blobs", prefetchedBlobs)
        }
        // This endpoint is not ETag-cached, but the header the ETag path uses carries exactly what the server needs
        // here, so it is reused verbatim: epoch millis, omitted entirely when there has been no successful refresh.
        val requestHeaders = lastRefreshTime?.let {
            backendHelper.authenticationHeaders +
                (HTTPRequest.LAST_REFRESH_TIME_HEADER_NAME to it.time.toString())
        } ?: backendHelper.authenticationHeaders

        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    baseURL,
                    endpoint,
                    body = body,
                    postFieldsToSign = null,
                    requestHeaders,
                    iamAppUserID = appUserID,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    remoteConfigCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    // Transport/IO failure: no HTTP status, the endpoint may recover on a future sync.
                    onErrorHandler(error, GetRemoteConfigErrorHandlingBehavior.SHOULD_RETRY)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    remoteConfigCallbacks.remove(cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        if (result.responseCode == RCHTTPStatusCodes.NO_CONTENT) {
                            // 204: nothing changed, no container to parse.
                            onSuccessHandler(null, result.requestDate, result.verificationResult)
                            return@forEach
                        }
                        val payload = result.payload
                        if (payload !is HTTPResult.Payload.RCFormat) {
                            onErrorHandler(
                                PurchasesError(
                                    PurchasesErrorCode.UnknownError,
                                    "Expected an RC Container Format payload for remote config.",
                                ).also { errorLog(it) },
                                // A 2xx with an unexpected payload is not a client error; keep retrying.
                                GetRemoteConfigErrorHandlingBehavior.SHOULD_RETRY,
                            )
                            return@forEach
                        }
                        try {
                            onSuccessHandler(
                                RCContainer.parse(payload.bytes),
                                result.requestDate,
                                result.verificationResult,
                            )
                        } catch (e: RCContainerFormatException) {
                            // Parse failure of an otherwise-successful response; keep retrying.
                            onErrorHandler(
                                e.toPurchasesError().also { errorLog(it) },
                                GetRemoteConfigErrorHandlingBehavior.SHOULD_RETRY,
                            )
                        }
                    } else {
                        // A 4xx means the endpoint intentionally refused, so don't retry against the fallback.
                        // Any other non-success (5xx) may recover, so a cold start may try the fallback.
                        val isClientError = !RCHTTPStatusCodes.isSuccessful(result.responseCode) &&
                            !RCHTTPStatusCodes.isServerError(result.responseCode)
                        val behavior = if (isClientError) {
                            GetRemoteConfigErrorHandlingBehavior.SHOULD_NOT_TRY_FALLBACK
                        } else {
                            GetRemoteConfigErrorHandlingBehavior.SHOULD_RETRY
                        }
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) }, behavior)
                    }
                }
            }
        }

        synchronized(this@Backend) {
            val delay = Delay.jitterOnlyIfInBackground(appInBackground)
            remoteConfigCallbacks.addBackgroundAwareCallback(
                call,
                remoteConfigDispatcher,
                cacheKey,
                onSuccess to onError,
                delay,
            )
        }
    }

    fun getRemoteConfigFallback(
        appInBackground: Boolean,
        domain: String,
        onSuccess: (RemoteConfiguration, SignatureVerificationResult) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        val fallbackURL = appConfig.fallbackBaseURLs.firstOrNull()
        if (fallbackURL == null) {
            onError(
                PurchasesError(
                    PurchasesErrorCode.UnknownError,
                    "No fallback base URL configured for remote config.",
                ).also { errorLog(it) },
            )
            return
        }
        val endpoint = Endpoint.GetRemoteConfigFallback(domain)
        val cacheKey = BackgroundAwareCallbackCacheKey(listOf(endpoint.getPath()), appInBackground)

        val call = object : Dispatcher.AsyncCall() {
            override fun call(): HTTPResult {
                return httpClient.performRequest(
                    fallbackURL,
                    endpoint,
                    // A null body makes this a GET (getConnection only switches to POST when a body is present).
                    body = null,
                    postFieldsToSign = null,
                    backendHelper.authenticationHeaders,
                )
            }

            override fun onError(error: PurchasesError) {
                synchronized(this@Backend) {
                    remoteConfigFallbackCallbacks.remove(cacheKey)
                }?.forEach { (_, onErrorHandler) ->
                    onErrorHandler(error)
                }
            }

            override fun onCompletion(result: HTTPResult) {
                synchronized(this@Backend) {
                    remoteConfigFallbackCallbacks.remove(cacheKey)
                }?.forEach { (onSuccessHandler, onErrorHandler) ->
                    if (result.isSuccessful()) {
                        try {
                            onSuccessHandler(
                                RemoteConfiguration.parse(result.payloadText.encodeToByteArray()),
                                result.verificationResult,
                            )
                        } catch (e: SerializationException) {
                            onErrorHandler(e.toPurchasesError().also { errorLog(it) })
                        }
                    } else {
                        onErrorHandler(result.toPurchasesError().also { errorLog(it) })
                    }
                }
            }
        }

        synchronized(this@Backend) {
            val delay = Delay.jitterOnlyIfInBackground(appInBackground)
            remoteConfigFallbackCallbacks.addBackgroundAwareCallback(
                call,
                remoteConfigDispatcher,
                cacheKey,
                onSuccess to onError,
                delay,
            )
        }
    }

    fun clearCaches() {
        httpClient.clearCaches()
    }

    private fun determinePostReceiptErrorHandlingBehavior(
        responseCode: Int,
        purchasesError: PurchasesError,
    ) = if (RCHTTPStatusCodes.isServerError(responseCode)) {
        PostReceiptErrorHandlingBehavior.SHOULD_USE_OFFLINE_ENTITLEMENTS_AND_NOT_CONSUME
    } else if (purchasesError.code == PurchasesErrorCode.UnsupportedError) {
        PostReceiptErrorHandlingBehavior.SHOULD_NOT_CONSUME
    } else {
        PostReceiptErrorHandlingBehavior.SHOULD_BE_MARKED_SYNCED
    }

    @Synchronized
    private fun <S, E> MutableMap<BackgroundAwareCallbackCacheKey, MutableList<Pair<S, E>>>.addBackgroundAwareCallback(
        call: Dispatcher.AsyncCall,
        dispatcher: Dispatcher,
        cacheKey: BackgroundAwareCallbackCacheKey,
        functions: Pair<S, E>,
        delay: Delay = Delay.NONE,
    ) {
        val foregroundCacheKey = cacheKey.copy(appInBackground = false)
        val foregroundCallAlreadyInPlace = containsKey(foregroundCacheKey)
        val cacheKeyToUse = if (cacheKey.appInBackground && foregroundCallAlreadyInPlace) {
            debugLog { NetworkStrings.SAME_CALL_SCHEDULED_WITHOUT_JITTER.format(foregroundCacheKey) }
            foregroundCacheKey
        } else {
            cacheKey
        }
        addCallback(call, dispatcher, cacheKeyToUse, functions, delay)
        // In case we have a request with a jittered delay queued, and we perform the same request without
        // jittered delay, we want to call the callback using the unjittered request
        val backgroundedCacheKey = cacheKey.copy(appInBackground = true)
        val backgroundCallAlreadyInPlace = containsKey(foregroundCacheKey)
        if (!cacheKey.appInBackground && backgroundCallAlreadyInPlace) {
            debugLog { NetworkStrings.SAME_CALL_SCHEDULED_WITH_JITTER.format(foregroundCacheKey) }
            remove(backgroundedCacheKey)?.takeIf { it.isNotEmpty() }?.let { backgroundedCallbacks ->
                if (containsKey(cacheKey)) {
                    this[cacheKey]?.addAll(backgroundedCallbacks)
                } else {
                    this[cacheKey] = backgroundedCallbacks
                }
            }
        }
    }

    private fun <K, F> MutableMap<K, MutableList<F>>.addCallback(
        call: Dispatcher.AsyncCall,
        dispatcher: Dispatcher,
        cacheKey: K,
        functions: F,
        delay: Delay = Delay.NONE,
    ) {
        if (!containsKey(cacheKey)) {
            this[cacheKey] = mutableListOf(functions)
            backendHelper.enqueue(call, dispatcher, delay)
        } else {
            debugLog { String.format(NetworkStrings.SAME_CALL_ALREADY_IN_PROGRESS, cacheKey) }
            this[cacheKey]!!.add(functions)
        }
    }
}

internal data class BackgroundAwareCallbackCacheKey(
    val cacheKey: List<String>,
    val appInBackground: Boolean,
)

internal fun PricingPhase.toMap(): Map<String, Any?> {
    return mapOf(
        "billingPeriod" to this.billingPeriod.iso8601,
        "billingCycleCount" to this.billingCycleCount,
        "recurrenceMode" to this.recurrenceMode.identifier,
        "formattedPrice" to this.price.formatted,
        "priceAmountMicros" to this.price.amountMicros,
        "priceCurrencyCode" to this.price.currencyCode,
    )
}
