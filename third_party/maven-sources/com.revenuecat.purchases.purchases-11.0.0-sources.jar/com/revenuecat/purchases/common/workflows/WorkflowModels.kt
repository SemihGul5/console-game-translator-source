@file:OptIn(InternalRevenueCatAPI::class)

package com.revenuecat.purchases.common.workflows

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.paywalls.components.common.ComponentsConfig
import com.revenuecat.purchases.paywalls.components.common.ExitOffers
import com.revenuecat.purchases.paywalls.components.common.LocaleId
import com.revenuecat.purchases.paywalls.components.common.LocalizationData
import com.revenuecat.purchases.paywalls.components.common.LocalizationKey
import com.revenuecat.purchases.paywalls.components.common.LocalizedVideoMapSerializer
import com.revenuecat.purchases.paywalls.components.common.ProductChangeConfig
import com.revenuecat.purchases.paywalls.components.common.ProductChangeConfigSerializer
import com.revenuecat.purchases.paywalls.components.common.StateDeclaration
import com.revenuecat.purchases.paywalls.components.common.StateDeclarationMapSerializer
import com.revenuecat.purchases.paywalls.components.properties.ThemeVideoUrls
import com.revenuecat.purchases.utils.serializers.DefaultLocaleIdSerializer
import com.revenuecat.purchases.utils.serializers.EnumDeserializerWithDefault
import com.revenuecat.purchases.utils.serializers.GoogleListSerializer
import com.revenuecat.purchases.utils.serializers.JsonObjectToMapSerializer
import com.revenuecat.purchases.utils.serializers.SealedDeserializerWithDefault
import com.revenuecat.purchases.utils.serializers.URLSerializer
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.net.URL

@InternalRevenueCatAPI
@Serializable(with = WorkflowTriggerTypeDeserializer::class)
public enum class WorkflowTriggerType {
    @SerialName("on_press")
    ON_PRESS,
    UNKNOWN,
}

internal object WorkflowTriggerTypeDeserializer : EnumDeserializerWithDefault<WorkflowTriggerType>(
    serialName = "com.revenuecat.purchases.common.workflows.WorkflowTriggerType",
    defaultValue = WorkflowTriggerType.UNKNOWN,
)

@InternalRevenueCatAPI
@Serializable(with = WorkflowTriggerActionSerializer::class)
public sealed class WorkflowTriggerAction {
    @InternalRevenueCatAPI
    @Serializable
    public data class Step(@SerialName("step_id") val stepId: String) : WorkflowTriggerAction()

    /**
     * Routes to the first branch whose audience matches, and to [fallbackStepId] otherwise. The audience
     * rules arrive in the `audiences` topic, so only the id is carried here.
     */
    @InternalRevenueCatAPI
    @Serializable
    public data class Branch(
        val routes: List<Route>,
        @SerialName("fallback_step_id") val fallbackStepId: String,
    ) : WorkflowTriggerAction() {
        @InternalRevenueCatAPI
        @Serializable
        public data class Route(
            @SerialName("audience_id") val audienceId: String,
            @SerialName("step_id") val stepId: String,
        )
    }

    @InternalRevenueCatAPI
    @Serializable
    public object Unknown : WorkflowTriggerAction()
}

internal object WorkflowTriggerActionSerializer : SealedDeserializerWithDefault<WorkflowTriggerAction>(
    serialName = "WorkflowTriggerAction",
    serializerByType = mapOf(
        "step" to { WorkflowTriggerAction.Step.serializer() },
        "branch" to { WorkflowTriggerAction.Branch.serializer() },
    ),
    defaultValue = { WorkflowTriggerAction.Unknown },
)

@InternalRevenueCatAPI
@Serializable
public data class WorkflowTrigger(
    val name: String,
    val type: WorkflowTriggerType,
    @SerialName("action_id") val actionId: String,
    @SerialName("component_id") val componentId: String,
)

/**
 * Step `screen_type` classification values and the metadata key they are returned under.
 *
 * The backend tags each step with its screen classification inside `metadata` (`metadata.screen_type`),
 * e.g. `["paywall"]`. The SDK uses this to decide which workflow steps report paywall events.
 */
@InternalRevenueCatAPI
public object WorkflowScreenType {

    /** The key the classification list is stored under inside a step's `metadata`. */
    public const val METADATA_KEY: String = "screen_type"

    /** A step whose screen is a paywall; it should report paywall impression/close events. */
    public const val PAYWALL: String = "paywall"
}

/**
 * Parsed workflow gate. Unknown gate types and malformed known fields are [Invalid] and fail closed: the workflow
 * is not served. Unknown keys are ignored so the backend can add fields without breaking shipped SDKs.
 */
@InternalRevenueCatAPI
public sealed class WorkflowStepGating {
    public object Soft : WorkflowStepGating()

    public data class Hard(val entitlementIdentifiers: Set<String>) : WorkflowStepGating()

    public object Invalid : WorkflowStepGating()
}

@InternalRevenueCatAPI
@Serializable
public data class WorkflowStep(
    val id: String,
    val type: String,
    @SerialName("screen_id") val screenId: String? = null,
    @SerialName("param_values") val paramValues: Map<String, JsonElement> = emptyMap(),
    val triggers: List<WorkflowTrigger> = emptyList(),
    val outputs: Map<String, JsonElement> = emptyMap(),
    @SerialName("trigger_actions") val triggerActions: Map<String, WorkflowTriggerAction> = emptyMap(),
    val metadata: JsonElement? = null,
) {
    /** The gate in `param_values.gating`, or `null` when the key is absent. */
    @InternalRevenueCatAPI
    public val gating: WorkflowStepGating?
        get() = paramValues[GATING_PARAM]?.let(::parseWorkflowStepGating)

    /**
     * The step's screen classification, as reported by the backend under `metadata.screen_type`.
     *
     * Returns `null` when the step was not tagged (older workflows, or workflows served before the
     * screen-analytics rollout) and an empty list when it was tagged with no known type. The
     * null-vs-empty distinction matters for paywall-event gating: an untagged step falls back to the
     * prior structural inference (`id == singleStepFallbackId`), while a step explicitly tagged without
     * `paywall` suppresses paywall events. See `tracksPaywallEvents` in the UI layer.
     */
    @InternalRevenueCatAPI
    public val stepScreenType: List<String>?
        get() {
            // A present-but-non-array `screen_type` (null, scalar, object) is treated the same as an
            // absent key: untagged (returns null), so events keep reporting. This matches the iOS
            // contract and is the conservative default; the backend only ever ships `screen_type` as a
            // JSON array, so suppressing on a malformed shape would risk muting real events.
            val metadataObject = metadata as? JsonObject ?: return null
            val screenType = metadataObject[WorkflowScreenType.METADATA_KEY] as? JsonArray ?: return null
            return screenType.mapNotNull { element ->
                (element as? JsonPrimitive)?.takeIf { it.isString }?.content
            }
        }

    /** Set on khepri's `<id>~f` fallback copies: the id of the step they were copied from. */
    @InternalRevenueCatAPI
    public val fallbackOriginalStepId: String?
        get() = (metadata as? JsonObject)?.get(FALLBACK_ORIGINAL_STEP_ID_KEY).stringOrNull()

    /** `metadata` first, `param_values` for blobs published before khepri moves them to `metadata`. */
    public val experimentId: String?
        get() = experimentValueFromMetadataOrParams(EXPERIMENT_ID_PARAM)

    public val experimentVariant: String?
        get() = experimentValueFromMetadataOrParams(EXPERIMENT_VARIANT_PARAM)

    /** A terminal step that resolves to an offering instead of rendering a screen. */
    @InternalRevenueCatAPI
    public val isOfferingStep: Boolean
        get() = type == OFFERING_STEP_TYPE

    /**
     * The offering this step presents, read from `param_values.offering.identifier`, or from
     * `param_values.offering_identifier` when the step carries the identifier flat.
     */
    @InternalRevenueCatAPI
    public val offeringIdentifier: String?
        get() {
            val nested = (paramValues[OFFERING_PARAM] as? JsonObject)?.get(OFFERING_IDENTIFIER_PARAM)
            return (nested ?: paramValues[FLAT_OFFERING_IDENTIFIER_PARAM])
                ?.let { it as? JsonPrimitive }
                ?.takeIf { it.isString }
                ?.content
                ?.takeIf { it.isNotBlank() }
        }

    private fun experimentValueFromMetadataOrParams(key: String): String? =
        (metadata as? JsonObject)?.get(key).stringOrNull() ?: paramValues[key].stringOrNull()

    private fun JsonElement?.stringOrNull(): String? =
        (this as? JsonPrimitive)?.takeIf { it.isString }?.content
}

private const val EXPERIMENT_ID_PARAM = "experiment_id"
private const val EXPERIMENT_VARIANT_PARAM = "experiment_variant"
private const val FALLBACK_ORIGINAL_STEP_ID_KEY = "fallback_original_step_id"
private const val OFFERING_STEP_TYPE = "offering"
private const val OFFERING_PARAM = "offering"
private const val OFFERING_IDENTIFIER_PARAM = "identifier"
private const val FLAT_OFFERING_IDENTIFIER_PARAM = "offering_identifier"
private const val GATING_PARAM = "gating"
private const val GATING_TYPE_KEY = "type"
private const val GATING_ENTITLEMENTS_KEY = "entitlement_identifiers"

private fun parseWorkflowStepGating(value: JsonElement): WorkflowStepGating {
    val gating = value as? JsonObject ?: return WorkflowStepGating.Invalid
    val type = (gating[GATING_TYPE_KEY] as? JsonPrimitive)?.takeIf { it.isString }?.content
    return when (type) {
        "soft" -> if (GATING_ENTITLEMENTS_KEY in gating) WorkflowStepGating.Invalid else WorkflowStepGating.Soft
        "hard" -> parseHardWorkflowStepGating(gating)
        else -> WorkflowStepGating.Invalid
    }
}

@Suppress("ReturnCount")
private fun parseHardWorkflowStepGating(gating: JsonObject): WorkflowStepGating {
    val elements = gating[GATING_ENTITLEMENTS_KEY] as? JsonArray ?: return WorkflowStepGating.Invalid
    val identifiers = elements.mapNotNull { element ->
        (element as? JsonPrimitive)?.takeIf { it.isString }?.content?.takeIf { it.isNotBlank() }
    }
    if (identifiers.isEmpty() || identifiers.size != elements.size || identifiers.distinct().size != identifiers.size) {
        return WorkflowStepGating.Invalid
    }
    return WorkflowStepGating.Hard(identifiers.toSet())
}

@InternalRevenueCatAPI
@Serializable
public data class WorkflowScreen(
    val name: String? = null,
    @SerialName("template_name") val templateName: String,
    val revision: Int = 0,
    @Serializable(with = URLSerializer::class)
    @SerialName("asset_base_url") val assetBaseURL: URL,
    @SerialName("components_config") val componentsConfig: ComponentsConfig,
    @SerialName("components_localizations")
    val componentsLocalizations: Map<LocaleId, Map<LocalizationKey, LocalizationData>>,
    @Serializable(with = DefaultLocaleIdSerializer::class)
    @SerialName("default_locale") val defaultLocaleIdentifier: LocaleId = DefaultLocaleIdSerializer.FALLBACK,
    @SerialName("config") val config: JsonObject = JsonObject(emptyMap()),
    @SerialName("offering_identifier") val offeringIdentifier: String? = null,
    @Serializable(with = GoogleListSerializer::class)
    @SerialName("zero_decimal_place_countries") val zeroDecimalPlaceCountries: List<String> = emptyList(),
    @SerialName("exit_offers") val exitOffers: ExitOffers? = null,
    @Serializable(with = ProductChangeConfigSerializer::class)
    @SerialName("play_store_product_change_mode") val productChangeConfig: ProductChangeConfig? = null,
    @SerialName("automatically_scale_font_size") val automaticallyScaleFontSize: Boolean = true,
    @Serializable(with = StateDeclarationMapSerializer::class)
    @SerialName("state_declarations") val stateDeclarations: Map<String, StateDeclaration>? = null,
    @Serializable(with = LocalizedVideoMapSerializer::class)
    @SerialName("components_video_localizations")
    val componentsVideoLocalizations: Map<LocaleId, Map<LocalizationKey, ThemeVideoUrls>> = emptyMap(),
)

/**
 * Published workflow document returned inline or via CDN (same JSON shape).
 */
@InternalRevenueCatAPI
@Serializable
public data class PublishedWorkflow(
    val id: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("initial_step_id") val initialStepId: String,
    /** Set when the first screen is audience-routed. [initialStepId] names this branch's fallback. */
    @SerialName("initial_trigger") val initialTrigger: WorkflowTriggerAction? = null,
    val steps: Map<String, WorkflowStep>,
    val screens: Map<String, WorkflowScreen>,
    @Serializable(with = JsonObjectToMapSerializer::class)
    val metadata: Map<String, @Contextual Any> = emptyMap(),
    val hash: String? = null,
    @SerialName("single_step_fallback_id") val singleStepFallbackId: String? = null,
) {
    @InternalRevenueCatAPI
    public val dismissExitOffer: WorkflowExitOffer?
        get() {
            val stepId = singleStepFallbackId ?: return null
            val step = steps[stepId] ?: return null
            val screenId = step.screenId ?: return null
            val offeringId = screens[screenId]?.exitOffers?.dismiss?.offeringId ?: return null
            return WorkflowExitOffer(offeringId = offeringId, stepId = step.id)
        }

    /** The branch that has to route the first step before anything can render. */
    @InternalRevenueCatAPI
    public val initialBranch: WorkflowTriggerAction.Branch?
        get() = initialTrigger as? WorkflowTriggerAction.Branch
}

@InternalRevenueCatAPI
public data class WorkflowExitOffer(
    val offeringId: String,
    val stepId: String,
)
