package com.revenuecat.purchases.common.networking

import android.net.Uri
import com.revenuecat.purchases.common.errorLog

internal sealed class Endpoint(
    val pathTemplate: String,
    val name: String,
    val fallbackPath: String? = null,
) {
    abstract fun getPath(useFallback: Boolean = false, useIAMPath: Boolean = false): String

    /**
     * Whether this endpoint returns an RC Container Format response rather than JSON. When
     * `true`, the request advertises `Accept: application/x-rc-format` and the response body is exposed
     * as [HTTPResult.Payload.RCFormat] instead of being decoded as text.
     */
    open val expectsRCFormatResponse: Boolean = false

    /** IAM-namespace relative path, if this endpoint has been migrated. Falls back to [pathTemplate]. */
    open val iamPathTemplate: String? = null

    /** Whether this endpoint is part of the auth flow itself (paths under `/auth`), never reached via API key. */
    open val isIAMEndpoint: Boolean = false

    /** [iamPathTemplate] when [useIAMPath] is set and one exists, else [pathTemplate]. */
    protected fun templateFor(useIAMPath: Boolean): String =
        if (useIAMPath) iamPathTemplate ?: pathTemplate else pathTemplate

    data class GetCustomerInfo(val userId: String) : Endpoint("/v1/subscribers/%s", "get_customer") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId))
        override val iamPathTemplate: String? = "/v1/customer"
    }

    object PostReceipt : Endpoint("/v1/receipts", "post_receipt") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = templateFor(useIAMPath)
    }
    data class GetOfferings(val userId: String) : Endpoint(
        "/v1/subscribers/%s/offerings",
        "get_offerings",
        fallbackPath = "/v1/offerings",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean): String {
            return if (useFallback && fallbackPath != null) {
                fallbackPath
            } else {
                templateFor(useIAMPath).format(Uri.encode(userId))
            }
        }
        override val iamPathTemplate: String? = "/v1/customer/offerings"
    }

    object LogIn : Endpoint("/v1/subscribers/identify", "log_in") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean): String {
            if (useIAMPath) {
                errorLog { "LogIn has no IAM-path equivalent; falling back to the API-key path." }
            }
            return pathTemplate
        }
    }

    data class AliasUsers(val userId: String) : Endpoint("/v1/subscribers/%s/alias", "alias_users") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId))
    }

    object PostDiagnostics : Endpoint("/v1/diagnostics", "post_diagnostics") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = templateFor(useIAMPath)
    }

    object PostEvents : Endpoint("/v1/events", "post_paywall_events") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = templateFor(useIAMPath)
    }
    data class PostAttributes(
        val userId: String,
    ) : Endpoint("/v1/subscribers/%s/attributes", "post_attributes") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId))
        override val iamPathTemplate: String? = "/v1/customer/attributes"
    }

    // TODO(IAM): not yet supported server-side
    data class GetAmazonReceipt(
        val userId: String,
        val receiptId: String,
    ) : Endpoint("/v1/receipts/amazon/%s/%s", "get_amazon_receipt") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId), receiptId)
    }
    object GetProductEntitlementMapping : Endpoint(
        "/v1/product_entitlement_mapping",
        "get_product_entitlement_mapping",
        fallbackPath = "/v1/product_entitlement_mapping",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean): String {
            return if (useFallback && fallbackPath != null) {
                fallbackPath
            } else {
                templateFor(useIAMPath)
            }
        }
        override val iamPathTemplate: String? = "/v1/product_entitlement_mapping"
    }
    data class GetCustomerCenterConfig(val userId: String) : Endpoint(
        "/v1/customercenter/%s",
        "get_customer_center_config",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId))
        override val iamPathTemplate: String? = "/v1/customer/customercenter"
    }

    data class GetRemoteConfig(val domain: String) : Endpoint(
        pathTemplate = "/v1/config/%s",
        name = "remote_config",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(domain))
        override val expectsRCFormatResponse: Boolean = true
    }

    /**
     * Fallback for [GetRemoteConfig] served from a fallback base URL. Unlike the main endpoint, it is a plain
     * `GET` returning `application/json` (no `x-rc-format`, no inlined blobs, no request body), and its response
     * is signature-verified **without** a nonce (mirroring [GetOfferings]). The domain layer chooses this
     * endpoint explicitly; it does not participate in the generic HTTPClient URL-fallback mechanism.
     */
    data class GetRemoteConfigFallback(val domain: String) : Endpoint(
        pathTemplate = "/v1/config/%s",
        name = "remote_config_fallback",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(domain))
    }

    object PostCreateSupportTicket : Endpoint(
        "/v1/customercenter/support/create-ticket",
        "post_create_support_ticket",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = templateFor(useIAMPath)
        override val iamPathTemplate: String? = "/v1/customer/customercenter/support/create-ticket"
    }

    object PostRedeemWebPurchase : Endpoint(
        "/v1/subscribers/redeem_purchase",
        "post_redeem_web_purchase",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = templateFor(useIAMPath)
    }
    data class GetVirtualCurrencies(val userId: String) : Endpoint(
        pathTemplate = "/v1/subscribers/%s/virtual_currencies",
        name = "get_virtual_currencies",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) =
            templateFor(useIAMPath).format(Uri.encode(userId))
        override val iamPathTemplate: String? = "/v1/customer/virtual_currencies"
    }

    // IAM-only: the user comes from the access token, so there's no API-key path.
    object SpendVirtualCurrencies : Endpoint(
        pathTemplate = "/v1/customer/virtual_currencies/spend",
        name = "spend_virtual_currencies",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = pathTemplate
    }

    data class GetRewardVerification(
        val userId: String,
        val clientTransactionId: String,
        val adUnitId: String?,
    ) : Endpoint(
        pathTemplate = "/v1/subscribers/%s/ads/reward_verifications/%s",
        name = "get_reward_verification",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean): String {
            val path = if (useIAMPath && iamPathTemplate != null) {
                templateFor(useIAMPath).format(Uri.encode(clientTransactionId))
            } else {
                templateFor(useIAMPath).format(Uri.encode(userId), Uri.encode(clientTransactionId))
            }
            return adUnitId?.takeIf { it.isNotBlank() }?.let { "$path?ad_unit_id=${Uri.encode(it)}" } ?: path
        }
        override val iamPathTemplate: String? = "/v1/customer/ads/reward_verifications/%s"
    }

    data class WebBillingGetProducts(val userId: String, val productIds: Set<String>) : Endpoint(
        pathTemplate = "/rcbilling/v1/subscribers/%s/products?id=%s",
        name = "web_billing_get_products",
    ) {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean): String {
            val encodedProductIds = productIds.joinToString("&id=") { Uri.encode(it) }
            return if (useIAMPath && iamPathTemplate != null) {
                templateFor(useIAMPath).format(encodedProductIds)
            } else {
                templateFor(useIAMPath).format(Uri.encode(userId), encodedProductIds)
            }
        }
        override val iamPathTemplate: String? = "/rcbilling/v1/customer/products?id=%s"
    }
    object TokenLogin : Endpoint("/auth/login", "token_login") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = pathTemplate
        override val isIAMEndpoint: Boolean = true
    }
    object TokenRefresh : Endpoint("/auth/token", "token_refresh") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = pathTemplate
        override val isIAMEndpoint: Boolean = true
    }
    object TokenLogout : Endpoint("/auth/revoke", "token_logout") {
        override fun getPath(useFallback: Boolean, useIAMPath: Boolean) = pathTemplate
        override val isIAMEndpoint: Boolean = true
    }

    val supportsSignatureVerification: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            is GetOfferings,
            GetProductEntitlementMapping,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            SpendVirtualCurrencies,
            is GetRewardVerification,
            is GetRemoteConfig,
            is GetRemoteConfigFallback,
            ->
                true
            is GetAmazonReceipt,
            is PostAttributes,
            PostDiagnostics,
            PostEvents,
            is GetCustomerCenterConfig,
            PostCreateSupportTicket,
            is WebBillingGetProducts,
            is AliasUsers,
            TokenLogin,
            TokenRefresh,
            TokenLogout,
            ->
                false
        }

    val needsNonceToPerformSigning: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            SpendVirtualCurrencies,
            is GetRewardVerification,
            is GetRemoteConfig,
            ->
                true
            is GetAmazonReceipt,
            is GetOfferings,
            is PostAttributes,
            PostDiagnostics,
            PostEvents,
            GetProductEntitlementMapping,
            is GetCustomerCenterConfig,
            PostCreateSupportTicket,
            is WebBillingGetProducts,
            is AliasUsers,
            is GetRemoteConfigFallback,
            TokenLogin,
            TokenRefresh,
            TokenLogout,
            ->
                false
        }

    val supportsFallbackBaseURLs: Boolean
        get() = fallbackPath != null

    /**
     * Whether the domain layer aims this endpoint at a fallback host instead of the main API host.
     * Such attempts are fallback attempts from the very first try, even though [HTTPClient]'s own
     * fallback walk never started, so they must not be treated as main-source requests.
     */
    val targetsFallbackHost: Boolean
        get() = this is GetRemoteConfigFallback

    /**
     * Whether this endpoint resolves its base host from the API source provider (the main-API host
     * list, with failover) rather than the app's static base URL. Endpoints hosted elsewhere
     * (diagnostics, events) opt out.
     */
    val usesAPISources: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            is GetOfferings,
            is AliasUsers,
            is PostAttributes,
            is GetAmazonReceipt,
            GetProductEntitlementMapping,
            is GetCustomerCenterConfig,
            is GetRemoteConfig,
            PostCreateSupportTicket,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            SpendVirtualCurrencies,
            is GetRewardVerification,
            is WebBillingGetProducts,
            TokenLogin,
            TokenRefresh,
            TokenLogout,
            ->
                true
            PostDiagnostics,
            PostEvents,
            is GetRemoteConfigFallback,
            ->
                false
        }
}
