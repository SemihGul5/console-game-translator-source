package com.revenuecat.purchases.rules.operators

import com.revenuecat.purchases.rules.Evaluator
import com.revenuecat.purchases.rules.RulesEngine.EvaluationException
import com.revenuecat.purchases.rules.Scope
import com.revenuecat.purchases.rules.Value
import com.revenuecat.purchases.rules.customoperators.CustomOperators

/**
 * JSON Logic operator dispatcher and shared helpers.
 *
 * Operators are responsible for evaluating their own arguments. Most use
 * the [evalTwo] / [evalArgs] helpers which evaluate eagerly; short-circuit
 * operators (`and`, `or`, `if`) iterate manually.
 */
internal object Operators {

    /**
     * Dispatch a JSON Logic operator. Throws
     * [EvaluationException.UnsupportedOperator] when the operator name isn't
     * implemented in this slice.
     */
    @Suppress("ComplexMethod", "ReturnCount")
    fun dispatch(
        op: String,
        args: Value,
        vars: Scope,
    ): Value = when (op) {
        // Accessors
        "var" -> AccessorOperators.opVar(args, vars)
        "missing" -> AccessorOperators.opMissing(args, vars)
        "missing_some" -> AccessorOperators.opMissingSome(args, vars)

        // Equality
        "==" -> EqualityOperators.opLooseEq(args, vars)
        "!=" -> EqualityOperators.opLooseNe(args, vars)
        "===" -> EqualityOperators.opStrictEq(args, vars)
        "!==" -> EqualityOperators.opStrictNe(args, vars)

        // Logic
        "!" -> LogicOperators.opNot(args, vars)
        "!!" -> LogicOperators.opNotNot(args, vars)
        "and" -> LogicOperators.opAnd(args, vars)
        "or" -> LogicOperators.opOr(args, vars)
        "if" -> LogicOperators.opIf(args, vars)

        // Arithmetic
        "+" -> ArithmeticOperators.opAdd(args, vars)
        "-" -> ArithmeticOperators.opSub(args, vars)
        "*" -> ArithmeticOperators.opMul(args, vars)
        "/" -> ArithmeticOperators.opDiv(args, vars)
        "%" -> ArithmeticOperators.opMod(args, vars)

        // Min and max
        "min" -> MinMaxOperators.opMin(args, vars)
        "max" -> MinMaxOperators.opMax(args, vars)

        // Comparison
        "<" -> ComparisonOperators.opLt(args, vars)
        "<=" -> ComparisonOperators.opLe(args, vars)
        ">" -> ComparisonOperators.opGt(args, vars)
        ">=" -> ComparisonOperators.opGe(args, vars)

        // String and array
        "in" -> StringArrayOperators.opIn(args, vars)
        "cat" -> StringArrayOperators.opCat(args, vars)
        "substr" -> StringArrayOperators.opSubstr(args, vars)
        "merge" -> StringArrayOperators.opMerge(args, vars)

        // Iteration
        "some" -> IterationOperators.opSome(args, vars)
        "all" -> IterationOperators.opAll(args, vars)
        "none" -> IterationOperators.opNone(args, vars)
        "map" -> IterationOperators.opMap(args, vars)
        "filter" -> IterationOperators.opFilter(args, vars)
        "reduce" -> IterationOperators.opReduce(args, vars)

        // Miscellaneous
        "log" -> MiscOperators.opLog(args, vars)

        else -> CustomOperators.dispatch(op, args, vars)
    }

    /**
     * Treat an operator argument as an argument list. Per JSON Logic, a
     * single-value argument is implicitly wrapped in a one-element list,
     * so `{"!": true}` and `{"!": [true]}` are equivalent.
     */
    fun argsAsList(args: Value): List<Value> = when (args) {
        is Value.ArrayValue -> args.items
        else -> listOf(args)
    }

    /** Evaluate every element in an argument list. */
    fun evalArgs(
        args: Value,
        vars: Scope,
    ): List<Value> = argsAsList(args).map { Evaluator.evaluateValue(it, vars) }

    /**
     * Rejects an argument count no overload of [operatorName] accepts.
     *
     * Only for operators that are strict about arity. Several others take a
     * fixed number of arguments and silently ignore extras — `substr`, `<`,
     * `reduce`, and anything reading through [firstArgEvaluated] — matching
     * `json-logic-js`, where a spread call simply drops what the function
     * does not declare. Whether an operator is strict is a decision each one
     * makes; this only spells the refusal the same way every time.
     */
    fun checkArity(count: Int, allowed: List<Int>, operatorName: String) {
        if (count !in allowed) {
            val expected = allowed.joinToString(" or ")
            throw EvaluationException.TypeMismatch(
                "operator '$operatorName' expects $expected arguments, got $count",
            )
        }
    }

    /**
     * Evaluate args and return the first two operands. Missing operands
     * default to [Value.Undefined] (JS omitted-argument semantics:
     * `function(a, b)` sees `undefined` for absent args, so e.g.
     * `{"===": [{"and": []}]}` is `undefined === undefined`) and extras
     * are silently discarded.
     */
    fun evalTwo(
        args: Value,
        vars: Scope,
    ): Pair<Value, Value> {
        val evaluated = evalArgs(args, vars)
        val lhs = evaluated.firstOrNull() ?: Value.Undefined
        val rhs = if (evaluated.size >= 2) evaluated[1] else Value.Undefined
        return lhs to rhs
    }

    /**
     * Evaluate the first argument of a unary operator. Uses [argsAsList]
     * then takes index zero, matching `json-logic-js`'s
     * `operations[op].apply(context, values)` spread semantics: a
     * multi-element top-level array is a multi-argument call, not a
     * single array operand. An empty arg list yields [Value.Null].
     */
    fun firstArgEvaluated(
        args: Value,
        vars: Scope,
    ): Value {
        val first = argsAsList(args).firstOrNull() ?: Value.Null
        return Evaluator.evaluateValue(first, vars)
    }

    /**
     * Safely truncate a [Double] to [Int] for index / count math.
     * `NaN` → `0` (matches JS `ToInteger`); `±Infinity` and
     * out-of-range finite values clamp to [Int.MAX_VALUE] / [Int.MIN_VALUE].
     */
    @Suppress("ReturnCount")
    fun clampedInt(value: Double): Int {
        if (value.isNaN()) return 0
        if (value >= Int.MAX_VALUE.toDouble()) return Int.MAX_VALUE
        if (value <= Int.MIN_VALUE.toDouble()) return Int.MIN_VALUE
        return value.toInt()
    }
}
