package com.revenuecat.purchases.rules.operators

import com.revenuecat.purchases.rules.Evaluator
import com.revenuecat.purchases.rules.Scope
import com.revenuecat.purchases.rules.Value

/**
 * Iteration operators: `some`, `all`, `none`, `map`, `filter`, `reduce`.
 *
 * All six follow the JSON Logic JS reference (`json-logic-js`):
 *
 * - **Shape** (`some` / `all` / `none` / `map` / `filter`):
 *   `{"<op>": [arrayExpr, predicateExpr]}`. The first argument is
 *   evaluated in the outer scope and must resolve to an array; anything
 *   else is treated as an empty source. The second argument is a
 *   literal template that is evaluated per-item with `vars` rebound to
 *   the current item, with no parent-scope inheritance for `var`; the
 *   preserved root scope remains available (`rc.rootVar` reads it).
 * - **Shape** (`reduce`):
 *   `{"reduce": [arrayExpr, predicateExpr, initialAccumulator]}`. Both
 *   the first and third arguments are evaluated in the outer scope.
 *   The predicate is evaluated per-item with `vars` rebound to
 *   `{"current": <item>, "accumulator": <acc>}`; `var` sees only that
 *   object, but `rc.rootVar` still reaches the root.
 *
 * **Empty- and non-array sources** per the JSON Logic JS spec:
 * - `some` / `all` return `false`.
 * - `none` returns `true`.
 * - `map` / `filter` return `[]`.
 * - `reduce` returns the initial accumulator unchanged.
 */
internal object IterationOperators {

    /**
     * `{"some": [arrayExpr, predicate]}` — `true` iff `predicate` is
     * truthy for at least one item. The array expression is evaluated in
     * the current scope; the predicate is re-evaluated per item with
     * `vars` rebound to that item (`var` reads the item; `rc.rootVar`
     * reads the root). Empty array or non-array source returns `false`.
     * Short-circuits on the first truthy result.
     */
    fun opSome(args: Value, vars: Scope): Value {
        val (items, predicate) = parseIterationArgs(args, vars)
        val result = items?.any { Evaluator.evaluateValue(predicate, vars.scoped(it)).isTruthy } ?: false
        return Value.BoolValue(result)
    }

    /**
     * `{"all": [arrayExpr, predicate]}` — `true` iff `predicate` is
     * truthy for every item. The array expression is evaluated in the
     * current scope; the predicate is re-evaluated per item with `vars`
     * rebound to that item (`var` reads the item; `rc.rootVar` reads the
     * root). Empty array returns `false` per the JSON Logic JS spec.
     * Non-array source returns `false`. Short-circuits on the first
     * non-truthy result.
     */
    fun opAll(args: Value, vars: Scope): Value {
        val (items, predicate) = parseIterationArgs(args, vars)
        val result = !items.isNullOrEmpty() &&
            items.all { Evaluator.evaluateValue(predicate, vars.scoped(it)).isTruthy }
        return Value.BoolValue(result)
    }

    /**
     * `{"none": [arrayExpr, predicate]}` — `true` iff `predicate` is
     * falsy for every item. Inverse of `some`. Short-circuits on the
     * first truthy item. Empty and non-array sources both return `true`,
     * matching the JS reference's `!Array.isArray(x) || !x.length` guard.
     */
    fun opNone(args: Value, vars: Scope): Value {
        val (items, predicate) = parseIterationArgs(args, vars)
        val result = items?.none { Evaluator.evaluateValue(predicate, vars.scoped(it)).isTruthy } ?: true
        return Value.BoolValue(result)
    }

    /**
     * `{"map": [arrayExpr, predicate]}` — apply `predicate` to each
     * item, return the new array of *raw* (non-truthy-coerced) results.
     * Empty or non-array source yields `[]`.
     */
    fun opMap(args: Value, vars: Scope): Value {
        val (items, predicate) = parseIterationArgs(args, vars)
        val results = items?.map { Evaluator.evaluateValue(predicate, vars.scoped(it)) } ?: emptyList()
        return Value.ArrayValue(results)
    }

    /**
     * `{"filter": [arrayExpr, predicate]}` — return only items for
     * which `predicate` is truthy. Empty or non-array source yields
     * `[]`. The retained items are the *original* values, not the
     * predicate results.
     */
    fun opFilter(args: Value, vars: Scope): Value {
        val (items, predicate) = parseIterationArgs(args, vars)
        val results = items?.filter { Evaluator.evaluateValue(predicate, vars.scoped(it)).isTruthy } ?: emptyList()
        return Value.ArrayValue(results)
    }

    /**
     * `{"reduce": [arrayExpr, predicate, initialAccumulator]}` — fold
     * over the array. The third argument is evaluated in the outer
     * scope to seed the accumulator, then the predicate is evaluated
     * once per item with `vars` rebound to
     * `{"current": item, "accumulator": acc}`. A non-array source
     * returns the seed unchanged. A missing predicate defaults to
     * [Value.Undefined] (so it evaluates to [Value.Undefined] per item,
     * matching `json-logic-js`'s `apply(undefined, …)`). A missing
     * initial accumulator defaults to [Value.Null] — `json-logic-js`
     * seeds the fold with `typeof values[2] !== "undefined" ? values[2]
     * : null`. Arguments past the third are ignored.
     */
    fun opReduce(args: Value, vars: Scope): Value {
        val raw = Operators.argsAsList(args)
        val sourceArg = raw.getOrNull(0) ?: Value.Null
        val predicate = raw.getOrNull(1) ?: Value.Undefined
        val source = Evaluator.evaluateValue(sourceArg, vars)
        var accumulator = raw.getOrNull(2)?.let { Evaluator.evaluateValue(it, vars) } ?: Value.Null
        val items = (source as? Value.ArrayValue)?.items ?: return accumulator
        for (item in items) {
            val itemScope = vars.scoped(
                Value.ObjectValue(mapOf("current" to item, "accumulator" to accumulator)),
            )
            accumulator = Evaluator.evaluateValue(predicate, itemScope)
        }
        return accumulator
    }

    /**
     * Parse `(items, predicate)` for an iteration operator. The source
     * argument is evaluated in the outer scope; the predicate template
     * is returned unevaluated so the caller can re-evaluate it per item
     * with the item as scope. `items` is `null` when the source does not
     * resolve to an array, so callers can distinguish a non-array source
     * from a genuinely empty one (`some`/`all` treat both as `false`, but
     * `none`/`map`/`filter`/`reduce` need the distinction). A missing
     * predicate defaults to [Value.Undefined] (so it evaluates to
     * [Value.Undefined] per item, matching `json-logic-js`'s
     * `apply(undefined, …)`; observable via `map`'s raw results) and
     * arguments past the second are ignored, matching `json-logic-js`'s
     * `function(scopedData, scopedLogic)` signature.
     */
    private fun parseIterationArgs(
        args: Value,
        vars: Scope,
    ): Pair<List<Value>?, Value> {
        val raw = Operators.argsAsList(args)
        val sourceArg = raw.getOrNull(0) ?: Value.Null
        val predicate = raw.getOrNull(1) ?: Value.Undefined
        val source = Evaluator.evaluateValue(sourceArg, vars)
        val items = (source as? Value.ArrayValue)?.items
        return items to predicate
    }
}
