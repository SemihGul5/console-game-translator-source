package com.revenuecat.purchases.strings

internal object IdentityStrings {
    const val LOGGING_IN = "Logging in from %s -> %s"
    const val LOG_IN_SUCCESSFUL = "Logged in successfully as %s. Created: %s"
    const val IAM_LOGGING_IN = "Logging in from %s with %s"
    const val IAM_LOG_IN_SUCCESSFUL = "Logged in successfully as %s"
    const val IAM_LOG_OUT_ANONYMOUS_LOGIN_FAILED =
        "Logged out locally, but the anonymous IAM login failed; it will be retried on the next foreground: %s"
    const val IAM_TOKEN_STORAGE_UNAVAILABLE = "IAM token storage is unavailable, so IAM login and logout can't run"
    const val IAM_IDENTITY_CHANGED_DURING_REQUEST =
        "The current user changed while this request was in flight; its result was discarded"
    const val ALIAS_OLD_USER_ID_TO_CURRENT_SUCCESSFUL = "Successfully aliased old user ID %s to current user ID %s."
    const val LOG_IN_ERROR_MISSING_APP_USER_ID = "Error logging in: appUserID can't be null, empty or blank"
    const val IDENTIFYING_APP_USER_ID = "Identifying App User ID: %s"
    const val CONFIGURED_APP_USER_ID_DIFFERS_FROM_CACHED =
        "The App User ID passed to configure differs from the cached App User ID. " +
            "This does not automatically log in or alias the cached user. " +
            "Call logIn with the new App User ID to transfer purchases and attributes."
    const val EMPTY_APP_USER_ID_WILL_BECOME_ANONYMOUS = "Identifying with empty App User ID will be " +
        "treated as anonymous."
    const val SETTING_NEW_ANON_ID = "Setting new anonymous App User ID - %s"
    const val LOG_OUT_CALLED_ON_ANONYMOUS_USER = "Called logOut but the current user is anonymous"
    const val LOG_OUT_SUCCESSFUL = "Logged out successfully"
    const val INVALIDATING_CACHED_ETAG_CACHE = "Detected unverified cached CustomerInfo but verification " +
        "is enabled. Invalidating Etag cache."
    const val SWITCHING_USER = "Switching to user %s."
    const val SWITCHING_USER_SAME_APP_USER_ID = "switchUser called with the same appUserID as the current user %s. " +
        "This has no effect."
    const val CONFIGURING_WITH_PREVIEW_MODE_USER_ID = "Configuring with UI preview mode user ID"
    const val OPERATION_NOT_SUPPORTED_IN_PREVIEW_MODE = "Operation not supported in UI preview mode"
}
