package dev.drewhamilton.poko

/**
 * Denotes an experimental API that allows generating Poko functions individually; i.e. a class
 * could have `toString` or it could have `equals` and `hashCode`, without having all three.
 */
@RequiresOptIn
public annotation class IndependentFunctionsSupport

/**
 * Denotes an experimental API that enables the ability to skip a Poko class primary constructor
 * property when generating Poko functions.
 */
@RequiresOptIn
public annotation class SkipSupport

/**
 * Denotes an API that enables support for array content reading, which is experimental and may
 * change or break.
 */
@Deprecated("Array content support no longer requires opt-in")
@RequiresOptIn
public annotation class ArrayContentSupport
