// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.google.firebase.firestore.pipeline.evaluation

// === Debug Functions ===

internal val evaluateIsError: EvaluateFunction = unaryFunction { r: EvaluateResult ->
  EvaluateResult.boolean(r.isError)
}

internal val evaluateError: EvaluateFunction = { _ -> { _ -> EvaluateResultError } }

internal val evaluateExists: EvaluateFunction = unaryFunction { r: EvaluateResult ->
  when (r) {
    EvaluateResultError -> r
    EvaluateResultUnset -> EvaluateResult.FALSE
    is EvaluateResultValue -> EvaluateResult.TRUE
  }
}

internal val evaluateIsAbsent: EvaluateFunction = unaryFunction { r: EvaluateResult ->
  when (r) {
    EvaluateResultError -> r
    EvaluateResultUnset -> EvaluateResult.TRUE
    is EvaluateResultValue -> EvaluateResult.FALSE
  }
}
